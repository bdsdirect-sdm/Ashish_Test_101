import React from 'react'

const StaffList:React.FC = () => {
  return (
    <div>StaffList</div>
  )
}

export default StaffList