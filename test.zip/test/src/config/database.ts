import { Sequelize } from 'sequelize';

const sequelize = new Sequelize('assessment_5', 'root', 'Password123#@!', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

export default sequelize;