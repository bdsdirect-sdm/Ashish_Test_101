// routes/userRoutes.ts
import { Router } from 'express';
import { getAgencies, addUser, loginUser, check, userDetails } from '../controller/userController';
// import { getAgencies, addUser, getJobSeekersByAgency, getAgencyForJobSeeker, loginUser, check, userDetails } from '../controller/userController';
import {validateUser} from '../middleware/validateUser'
import { upload } from '../middleware/upload';

const router = Router();

router.get('/', check);
router.get('/agencies', getAgencies);
// router.post('/signup', upload.fields([{name:"profileImg"},{name:"resume"}]),validateUser, addUser);
router.post('/signup', validateUser, addUser);
router.get('/userDetails/:userId', userDetails)
router.post('/login',loginUser)

// router.get('/agency/:agencyId', getJobSeekersByAgency);
// router.get('/jobseeker/:jobSeekerId', getAgencyForJobSeeker);
export default router;
