import React from 'react'

const Forget:React.FC = () => {
  return (
    <div>Forget</div>
  )
}

export default Forget