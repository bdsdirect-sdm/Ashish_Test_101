import React from 'react'

const StaffList:React.FC = () => {
  return (
    <>
    {/* // <div className='staff-container'>StaffList</div> */}
    </>
  )
}

export default StaffList