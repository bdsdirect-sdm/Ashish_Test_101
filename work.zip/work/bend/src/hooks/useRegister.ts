import { useMutation } from 'react-query';
import api from '../services/api';

// Define the shape of the registration data
interface RegisterData {
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    gender: string;
    userType: string; // '1' for Job Seeker, '2' for Agency
    hobbies: string[];
    profileImage: File;
    resume?: File; // Only for Job Seekers
    associatedAgencyID?: string; // Only for Job Seekers
}

// Define the response shape from the backend
interface RegisterResponse {
    message: string;
}

// useRegister Hook
const useRegister = () => {
    return useMutation<RegisterResponse, Error, RegisterData>(
        async (data: RegisterData) => {
            const formData = new FormData();
            formData.append('firstName', data.firstName);
            formData.append('lastName', data.lastName);
            formData.append('email', data.email);
            formData.append('phoneNumber', data.phoneNumber);
            formData.append('gender', data.gender);
            formData.append('userType', data.userType);
            data.hobbies.forEach((hobby) => formData.append('hobbies', hobby));

            formData.append('profileImage', data.profileImage);

            if (data.userType === '1') { // Job Seeker
                if (data.resume) {
                    formData.append('resume', data.resume);
                }
                if (data.associatedAgencyID) {
                    formData.append('associatedAgencyID', data.associatedAgencyID);
                }
            }

            const response = await api.post<RegisterResponse>('/signup', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            return response.data;
        },
        {
            onError: (error) => {
                console.error('Registration Error:', error);
            },
            onSuccess: (data) => {
                console.log('Registration Success:', data.message);
            },
        }
    );
};

export default useRegister;
