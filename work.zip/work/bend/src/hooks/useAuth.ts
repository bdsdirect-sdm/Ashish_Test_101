import { useMutation } from 'react-query';
import api from '../services/api';
// import jwt_decode from 'jwt-decode'; 
import { jwtDecode } from 'jwt-decode';


interface LoginData {
    Email: string;
    Password: string;
}

interface DecodedToken {
    UserID: number;
    iat: number;
    exp: number;
    UserType: number;
}

export const useLogin = () => {
    return useMutation(async (data: LoginData) => {
        const response = await api.post('/login', data);
        const decoded: DecodedToken = jwtDecode(response.data.token); // Use jwt_decode correctly
        return { ...response.data, decoded };
    });
};
