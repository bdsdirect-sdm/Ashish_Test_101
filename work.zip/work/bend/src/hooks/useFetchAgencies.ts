import { useQuery } from 'react-query';
import api from '../services/api';

// Define the shape of an agency
interface Agency {
    UserID: number;
    AgencyName?: string;
    FirstName: string;
    LastName: string;
}

// Define the response shape from the backend
interface FetchAgenciesResponse {
    agencies: Agency[];
}

// useFetchAgencies Hook
const useFetchAgencies = () => {
    return useQuery<FetchAgenciesResponse, Error>(
        'agencies',
        async () => {
            const response = await api.get<FetchAgenciesResponse>('/agencies');
            console.log("Fetched agencies data:", response.data);
            return response.data;
        },
        {
            staleTime: 5 * 60 * 1000, // 5 minutes
            cacheTime: 10 * 60 * 1000, // 10 minutes
            onError: (error) => {
                console.error('Error fetching agencies:', error);
            },
        }
    );
};

export default useFetchAgencies;
