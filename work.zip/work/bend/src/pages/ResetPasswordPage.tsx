import React from 'react';
import { Formik, Form, Field, ErrorMessage, FormikHelpers } from 'formik';
import * as Yup from 'yup';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';
import { Alert, Button, Form as BootstrapForm } from 'react-bootstrap';

interface ResetPasswordFormValues {
    newPassword: string;
    confirmPassword: string;
}

const ResetPasswordPage: React.FC = () => {
    const navigate = useNavigate();
    const [message, setMessage] = React.useState<string | null>(null);
    const [error, setError] = React.useState<string | null>(null);

    const initialValues: ResetPasswordFormValues = {
        newPassword: '',
        confirmPassword: '',
    };

    // const validationSchema = Yup.object().shape({
    //     newPassword: Yup.string().min(6, 'Password must be at least 6 characters').required('New Password is required'),
    //     confirmPassword: Yup.string()
    //         .oneOf([Yup.ref('newPassword'), null], 'Passwords must match')
    //         .required('Confirm Password is required'),
    // });
    const validationSchema = Yup.object().shape({
        newPassword: Yup.string().min(6, 'Password must be at least 6 characters').required('New Password is required'),
        confirmPassword: Yup.string()
            .oneOf([Yup.ref('newPassword')], 'Passwords must match')  // Removed 'null'
            .required('Confirm Password is required'),
    });

    const onSubmit = async (values: ResetPasswordFormValues, actions: FormikHelpers<ResetPasswordFormValues>) => {
        try {
            await api.post('/auth/reset-password', { newPassword: values.newPassword });
            setMessage('Password reset successful. Redirecting to dashboard...');
            setTimeout(() => {
                navigate('/dashboard');
            }, 2000);
        } catch (err: any) {
            setError(err.response?.data?.message || 'Password reset failed.');
        }
    };

    return (
        <div className="container mt-5">
            <h2>Reset Password</h2>
            {message && <Alert variant="success">{message}</Alert>}
            {error && <Alert variant="danger">{error}</Alert>}
            <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit}>
                {() => (
                    <Form>
                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>New Password</BootstrapForm.Label>
                            <Field name="newPassword" type="password" className="form-control" />
                            <ErrorMessage name="newPassword" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>Confirm Password</BootstrapForm.Label>
                            <Field name="confirmPassword" type="password" className="form-control" />
                            <ErrorMessage name="confirmPassword" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        <Button variant="primary" type="submit">
                            Reset Password
                        </Button>
                    </Form>
                )}
            </Formik>
        </div>
    );
};

export default ResetPasswordPage;
