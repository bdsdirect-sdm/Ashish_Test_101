import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { Alert, Button } from 'react-bootstrap';

interface Profile {
    FirstName: string;
    LastName: string;
    Email: string;
    PhoneNumber: string;
    Gender: string;
    UserType: number;
    Hobbies: string[];
    ResumePath?: string;
    ProfilePicturePath?: string;
    AgencyName?: string;
    AssociatedAgencyID?: number;
    Agency?: {
        UserID: number;
        FirstName: string;
        LastName: string;
        AgencyName: string;
    };
    JobSeekers?: Array<{
        UserID: number;
        FirstName: string;
        LastName: string;
        Email: string;
        ResumePath: string;
    }>;
}

const ProfilePage: React.FC = () => {
    const [profile, setProfile] = useState<Profile | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const response = await api.get('/users/profile');
                setProfile(response.data);
            } catch (err: any) {
                setError(err.response?.data?.message || 'Error fetching profile');
            }
        };
        fetchProfile();
    }, []);

    if (error) return <Alert variant="danger">{error}</Alert>;
    if (!profile) return <div>Loading...</div>;

    return (
        <div className="container mt-5">
            <h2>Profile</h2>
            <p><strong>Name:</strong> {profile.FirstName} {profile.LastName}</p>
            <p><strong>Email:</strong> {profile.Email}</p>
            <p><strong>Phone Number:</strong> {profile.PhoneNumber}</p>
            <p><strong>Gender:</strong> {profile.Gender}</p>
            <p><strong>Hobbies:</strong> {profile.Hobbies.join(', ')}</p>

            {profile.UserType === 1 && (
                <>
                    {profile.Agency && (
                        <p><strong>Associated Agency:</strong> {profile.Agency.AgencyName}</p>
                    )}
                    {profile.ResumePath && (
                        <div>
                            <strong>Resume:</strong> <Button variant="link" onClick={() => window.open(`http://localhost:3000/${profile.ResumePath}`, '_blank')}>Download</Button>
                        </div>
                    )}
                    {profile.ProfilePicturePath && (
                        <div>
                            <strong>Profile Picture:</strong><br />
                            <img src={`http://localhost:3000/${profile.ProfilePicturePath}`} alt="Profile" width="150" />
                        </div>
                    )}
                </>
            )}

            {profile.UserType === 2 && (
                <>
                    <p><strong>Agency Name:</strong> {profile.AgencyName}</p>
                    {profile.JobSeekers && profile.JobSeekers.length > 0 && (
                        <div>
                            <strong>Associated Job Seekers:</strong>
                            <ul>
                                {profile.JobSeekers.map(js => (
                                    <li key={js.UserID}>
                                        {js.FirstName} {js.LastName} - <Button variant="link" onClick={() => window.open(`http://localhost:3000/${js.ResumePath}`, '_blank')}>Download Resume</Button>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    )}
                </>
            )}

            <Button variant="primary" className="mt-3" onClick={() => window.location.reload()}>
                Refresh
            </Button>
        </div>
    );
};

export default ProfilePage;
