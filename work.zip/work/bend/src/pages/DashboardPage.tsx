import React from 'react';
import { useQuery } from 'react-query';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';
import { Table, Button } from 'react-bootstrap';

interface JobSeeker {
    UserID: number;
    FirstName: string;
    LastName: string;
    Email:string;
    ResumePath: string;
}

interface Agency {
    UserID: number;
    FirstName: string;
    LastName: string;
    AgencyName: string;
}

const DashboardPage: React.FC = () => {
    const navigate = useNavigate();
    const { data, isLoading, error } = useQuery('dashboard', async () => {
        const response = await api.get('/users/dashboard');
        return response.data;
    });

    if (isLoading) return <div>Loading...</div>;
    if (error) return <div>Error loading dashboard.</div>;

    const token = localStorage.getItem('token');
    // Decode token to get user type (use a better method in production)
    const payload = token ? JSON.parse(atob(token.split('.')[1])) : null;
    const userType = payload?.UserType || 1;

    return (
        <div className="container mt-5">
            <h2>Dashboard</h2>
            {userType === 2 ? (
                <>
                    <h3>Job Seekers Associated with Your Agency</h3>
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Resume</th>
                            </tr>
                        </thead>
                        <tbody>
                            {data.jobSeekers.map((js: JobSeeker) => (
                                <tr key={js.UserID}>
                                    <td>{js.FirstName} {js.LastName}</td>
                                    <td>{js.Email}</td>
                                    <td>
                                        <Button variant="link" onClick={() => window.open(`http://localhost:3000/${js.ResumePath}`, '_blank')}>
                                            Download Resume
                                        </Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </>
            ) : (
                <>
                    <h3>Agencies You Are Associated With</h3>
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th>Agency Name</th>
                                <th>Contact</th>
                            </tr>
                        </thead>
                        <tbody>
                            {data.agencies.map((agency: Agency) => (
                                <tr key={agency.UserID}>
                                    <td>{agency.AgencyName}</td>
                                    <td>{agency.FirstName} {agency.LastName}</td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </>
            )}
        </div>
    );
};

export default DashboardPage;
