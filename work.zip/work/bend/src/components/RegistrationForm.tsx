import React from 'react';
import { Formik, Form, Field, ErrorMessage, FormikHelpers } from 'formik';
import * as Yup from 'yup';
import { Button, Form as BootstrapForm, Alert, Spinner } from 'react-bootstrap';
import useRegister from '../hooks/useRegister';
import useFetchAgencies from '../hooks/useFetchAgencies';

interface RegistrationValues {
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    gender: string;
    userType: string;
    hobbies: string[];
    profileImage: File | null;
    resume: File | null;
    associatedAgencyID: string;
}

const RegistrationForm: React.FC = () => {
    const { data: agenciesData, isLoading: isAgenciesLoading, error: agenciesError } = useFetchAgencies();
    const registerMutation = useRegister();

    const initialValues: RegistrationValues = {
        firstName: '',
        lastName: '',
        email: '',
        phoneNumber: '',
        gender: '',
        userType: '',
        hobbies: [],
        profileImage: null,
        resume: null,
        associatedAgencyID: '',
    };

    const validationSchema = Yup.object({
        firstName: Yup.string().max(100).required('First Name is required'),
        lastName: Yup.string().max(100).required('Last Name is required'),
        email: Yup.string().email('Invalid email').required('Email is required'),
        phoneNumber: Yup.string()
            .matches(/^[0-9]{10}$/, 'Phone number must be exactly 10 digits')
            .required('Phone number is required'),
        gender: Yup.string().required('Gender is required'),
        userType: Yup.string().required('User Type is required'),
        hobbies: Yup.array().min(1, 'Select at least one hobby'),
        profileImage: Yup.mixed()
            .required('Profile Image is required')
            .test('fileType', 'Only PNG and JPEG are allowed', (value:any) => {
                return value ? ['image/png', 'image/jpeg'].includes(value.type) : false;
            }),
    
        resume: Yup.mixed().when(['userType'],(userType:any, schema)=>{
            if(userType==='1')return Yup.mixed().required('Resume is required')
                return schema;
        }),
        associatedAgencyID: Yup.mixed().when(['userType'],(userType:any,schema)=>{
            if(userType==='1') return Yup.mixed().required('Associated Agency is required')
                return schema;
        })
        
    });

    const onSubmit = async (values: RegistrationValues, actions: FormikHelpers<RegistrationValues>) => {
        try {
            const registerData:any = {
                firstName: values.firstName,
                lastName: values.lastName,
                email: values.email,
                phoneNumber: values.phoneNumber,
                gender: values.gender,
                userType: values.userType,
                hobbies: values.hobbies,
                profileImage: values.profileImage || undefined, // Set to undefined if null
                resume: values.userType === '1' ? values.resume || undefined : undefined, // Ensure it's undefined if null
                associatedAgencyID: values.userType === '1' ? values.associatedAgencyID || undefined : undefined,
            };

            await registerMutation.mutateAsync(registerData);
            actions.resetForm();
            alert('Registration successful! Please check your email for login details.');
        } catch (error: any) {
            alert(error.message || 'Registration failed');
        } finally {
            actions.setSubmitting(false);
        }
    };

    return (
        <div className="container mt-5">
            <h2>Register</h2>
            {registerMutation.isError && (
                <Alert variant="danger">{registerMutation.error?.message || 'Registration failed'}</Alert>
            )}
            {registerMutation.isSuccess && (
                <Alert variant="success">Registration successful! Please check your email for login details.</Alert>
            )}
            <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit}>
                {({ values, setFieldValue, isSubmitting }) => (
                    <Form>
                        {/* First Name */}
                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>First Name</BootstrapForm.Label>
                            <Field name="firstName" className="form-control" />
                            <ErrorMessage name="firstName" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        {/* Last Name */}
                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>Last Name</BootstrapForm.Label>
                            <Field name="lastName" className="form-control" />
                            <ErrorMessage name="lastName" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        {/* Email */}
                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>Email</BootstrapForm.Label>
                            <Field name="email" type="email" className="form-control" />
                            <ErrorMessage name="email" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        {/* Phone Number */}
                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>Phone Number</BootstrapForm.Label>
                            <Field name="phoneNumber" className="form-control" />
                            <ErrorMessage name="phoneNumber" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        {/* Gender */}
                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>Gender</BootstrapForm.Label>
                            <div role="group" aria-labelledby="gender-group">
                                {['Male', 'Female', 'Other'].map((option) => (
                                    <BootstrapForm.Check
                                        key={option}
                                        type="radio"
                                        label={option}
                                        name="gender"
                                        value={option}
                                        onChange={() => setFieldValue('gender', option)}
                                    />
                                ))}
                            </div>
                            <ErrorMessage name="gender" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        {/* User Type */}
                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>User Type</BootstrapForm.Label>
                            <Field as="select" name="userType" className="form-control">
                                <option value="">Select User Type</option>
                                <option value="1">Job Seeker</option>
                                <option value="2">Agency</option>
                            </Field>
                            <ErrorMessage name="userType" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        {/* Hobbies */}
                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>Hobbies</BootstrapForm.Label>
                            <div role="group" aria-labelledby="checkbox-group">
                                {['Sports', 'Dance', 'Reading', 'Singing'].map((hobby) => (
                                    <BootstrapForm.Check
                                        key={hobby}
                                        type="checkbox"
                                        label={hobby}
                                        name="hobbies"
                                        value={hobby}
                                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                            if (e.target.checked) {
                                                setFieldValue('hobbies', [...values.hobbies, e.target.value]);
                                            } else {
                                                setFieldValue(
                                                    'hobbies',
                                                    values.hobbies.filter((item) => item !== e.target.value)
                                                );
                                            }
                                        }}
                                    />
                                ))}
                            </div>
                            <ErrorMessage name="hobbies" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        {/* Profile Image */}
                        <BootstrapForm.Group className="mb-3">
                            <BootstrapForm.Label>Profile Image (PNG, JPEG)</BootstrapForm.Label>
                            <BootstrapForm.Control
                                type="file"
                                accept="image/png, image/jpeg"
                                onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                                    if (event.currentTarget.files) {
                                        setFieldValue('profileImage', event.currentTarget.files[0]);
                                    }
                                }}
                            />
                            <ErrorMessage name="profileImage" component="div" className="text-danger" />
                        </BootstrapForm.Group>

                        {/* Conditional Fields for Job Seekers */}
                        {values.userType === '1' && (
                            <>
                                {/* Resume */}
                                <BootstrapForm.Group className="mb-3">
                                    <BootstrapForm.Label>Resume (.pdf, .docx)</BootstrapForm.Label>
                                    <BootstrapForm.Control
                                        type="file"
                                        accept=".pdf, .docx"
                                        onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                                            if (event.currentTarget.files) {
                                                setFieldValue('resume', event.currentTarget.files[0]);
                                            }
                                        }}
                                    />
                                    <ErrorMessage name="resume" component="div" className="text-danger" />
                                </BootstrapForm.Group>

                                {/* Associated Agency */}
                                <BootstrapForm.Group className="mb-3">
                                    <BootstrapForm.Label>Select Agency</BootstrapForm.Label>
                                    <Field as="select" name="associatedAgencyID" className="form-control">
                                        <option value="">Select Agency</option>
                                        {isAgenciesLoading ? (
                                            <option disabled>Loading agencies...</option>
                                        ) : agenciesError ? (
                                            <option disabled>Error loading agencies</option>
                                        ) : (
                                            agenciesData?.agencies.map((agency) => (
                                                <option key={agency.UserID} value={agency.UserID}>
                                                    {agency.AgencyName || `${agency.FirstName} ${agency.LastName}`}
                                                </option>
                                            ))
                                        )}
                                    </Field>
                                    <ErrorMessage name="associatedAgencyID" component="div" className="text-danger" />
                                </BootstrapForm.Group>
                            </>
                        )}

                        {/* Submit Button */}
                        <Button variant="primary" type="submit" disabled={isSubmitting || registerMutation.isLoading}>
                            {isSubmitting || registerMutation.isLoading ? (
                                <>
                                    <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />
                                    {' Registering...'}
                                </>
                            ) : (
                                'Register'
                            )}
                        </Button>
                    </Form>
                )}
            </Formik>
        </div>
    );
};

export default RegistrationForm;
