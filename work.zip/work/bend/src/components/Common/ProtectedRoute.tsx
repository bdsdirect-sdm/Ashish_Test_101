import React from 'react';
import { Navigate } from 'react-router-dom';
import { jwtDecode } from 'jwt-decode';  // Use named import for jwtDecode

interface ProtectedRouteProps {
    children: JSX.Element;
    roles?: number[]; // 1 = Job Seeker, 2 = Agency
}

interface DecodedToken {
    UserID: number;
    iat: number;
    exp: number;
    UserType: number;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, roles }) => {
    const token = localStorage.getItem('token');

    if (!token) {
        return <Navigate to="/login" />;
    }

    try {
        const decoded: DecodedToken = jwtDecode(token);  // Call jwtDecode directly
        const currentTime = Date.now() / 1000; // Get current time in seconds

        if (decoded.exp < currentTime) {
            return <Navigate to="/login" />;
        }

        if (roles && !roles.includes(decoded.UserType)) {
            return <Navigate to="/dashboard" />;
        }
    } catch (error) {
        console.error('Token decoding failed:', error);
        return <Navigate to="/login" />;
    }

    return children;
};

export default ProtectedRoute;
