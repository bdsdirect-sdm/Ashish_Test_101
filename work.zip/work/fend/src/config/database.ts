import { Sequelize } from 'sequelize';

const sequelize = new Sequelize('job_portal', 'root', 'Password123#@!', {
  host: 'localhost',
  dialect: 'mysql',
  logging: true
});

export default sequelize;