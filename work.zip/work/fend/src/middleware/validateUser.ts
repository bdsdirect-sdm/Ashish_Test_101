import Joi from "joi";

export const validateUser = (req: any, res: any, next: any) => {
    const validateUserSchema = Joi.object({
        firstName: Joi.string().required().messages({
            'string.base': 'First name must be a string',
            'any.required': 'First name is required',
        }),
        lastName: Joi.string().required().messages({
            'string.base': 'Last name must be a string',
            'any.required': 'Last name is required',
        }),
        email: Joi.string().email().required().messages({
            'string.email': 'Invalid email format',
            'any.required': 'Email is required',
        }),
        gender: Joi.string().required().messages({
            'any.required': 'Gender is required',
        }),
        contact: Joi.string().length(10).required().messages({
            'string.length': 'Contact number must be exactly 10 digits',
            'any.required': 'Contact number is required',
        }),
        role: Joi.number().integer().required().messages({
            'number.base': 'Role must be a number',
            'any.required': 'Role is required',
        }),
    });

    const { error } = validateUserSchema.validate(req.body);
    
    if (error) {
        const msg = error.details.map((el) => el.message).join(', ');
        return res.status(400).json({ message: msg }); // Use 400 for validation errors
    }
    
    next();
};
