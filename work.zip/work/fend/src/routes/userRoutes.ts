// routes/userRoutes.ts
import { Router } from 'express';
import { getAgencies, addUser, loginUser, check, userDetails } from '../controller/userController';
import { validateUser } from '../middleware/validateUser';
import { upload } from '../middleware/upload';

const router = Router();

// General route for checking if the API is reachable
router.get('/', check);

// Fetch the list of agencies for registration form (React: Agencies Dropdown)
router.get('/agencies', getAgencies);

// User signup (React: /signup or /register) - you can adjust this based on your front-end route
router.post('/signup',
     upload.fields([{ name: "profileImage" }, 
        { name: "resume" }]),
         validateUser, addUser);

// User login (React: /login)
router.post('/login', loginUser);

// Fetch user details (React: /profile or specific user data)
router.get('/userDetails/:userId', userDetails);

export default router;
