import express from 'express';
const app = express();
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
app.use(cors());
const server = http.createServer(app);

const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"],
    },
});

io.on('connection', (socket:any) => {
    console.log(`User connected: ${socket.id}`);

    socket.on("join_room", (data:any) => { socket.join(data); });

    socket.on("send_message", (data:any) => {
       
        socket.to(data.room).emit("reciver_message", data);
    });

});

server.listen(3001, () => {
    return console.log(`Server is listening on port 3001`);
});

