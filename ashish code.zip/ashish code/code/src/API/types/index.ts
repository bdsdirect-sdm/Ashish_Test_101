import { User } from '@typing/global';

export type UserResponse = {
    token: string;
    user: User;
};
