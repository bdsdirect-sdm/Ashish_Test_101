import { axios } from '@axios';
import { useQuery } from 'react-query';
import { ExtractFnReturnType, QueryConfig } from '../../lib/react-query';
import { Address } from '@typing/global';

export const getDoctorAddresses = ({
    referralId,
}: {
    referralId: string;
}): Promise<any> => {
    return axios.get(`patient/consult-notes/${referralId}`);
};

export const addConsultNote = ({
    referralId,
    payload,
}: {
    referralId: number;
    payload: FormData;
}): Promise<any> => {
    return axios.post(`patient/consult-notes/${referralId}`, payload);
};

type QueryFnType = typeof getDoctorAddresses;

type UseDoctorsAddressesOptions = {
    referralId: string;
    config?: QueryConfig<QueryFnType>;
};

export const usePaitentConsultNotes = ({
    referralId,
    config,
}: UseDoctorsAddressesOptions) => {
    return useQuery<ExtractFnReturnType<QueryFnType>>({
        queryKey: ['paitent-consult-notes', referralId],
        queryFn: () =>
            referralId ? getDoctorAddresses({ referralId }) : false,
        select: (data: { data: Address[] }) => data.data,
        ...config,
    });
};
