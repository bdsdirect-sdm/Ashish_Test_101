import { axios } from '@axios';
import { useQuery } from 'react-query';
import { ExtractFnReturnType, QueryConfig } from '../../lib/react-query';

export const getInsurances = ({ search = '' }): Promise<any> => {
    return axios.get(`insurance?search=${search}`);
};

type QueryFnType = typeof getInsurances;

type UseInsurancesOptions = {
    params?: {
        search?: string;
    };
    config?: QueryConfig<QueryFnType>;
};

export const useInsurances = ({ params, config }: UseInsurancesOptions) => {
    return useQuery<ExtractFnReturnType<QueryFnType>>({
        queryKey: ['insurances'],
        queryFn: () => getInsurances(params),
        select: (res: any) => res.data,
        ...config,
    });
};
