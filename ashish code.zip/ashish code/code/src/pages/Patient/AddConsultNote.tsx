import React from 'react';
import * as yup from 'yup';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    Chip,
    Stack,
    Button as MuiButton,
    styled,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import './style.css';
import { failed, success } from '@components/Common/Toastify';
import TextInput from '@components/Common/TextInput';
import Button from '@components/Common/Button';
import { useFormik } from 'formik';
import TextArea from '@components/Common/TextArea';
import { addConsultNote } from '../../API/ConsultNote';

export const VisuallyHiddenInput = styled('input')({
    clip: 'rect(0 0 0 0)',
    clipPath: 'inset(50%)',
    height: 1,
    overflow: 'hidden',
    position: 'absolute',
    bottom: 0,
    left: 0,
    whiteSpace: 'nowrap',
    width: 1,
});

const AddConsultNote = ({
    isOpen,
    referralId,
    title = null,
    onClose,
    refetch,
}: {
    isOpen: boolean;
    title?: string;
    referralId: number;
    onClose: () => void;
    refetch: () => void;
}) => {
    const formik = useFormik({
        initialValues: {
            title: title || '',
            consultNotes: '',
            consultNoteDocuments: [] as File[],
        },
        validationSchema: yup.object({
            title: yup.string().required('Title is required'),
            consultNotes: yup.string().required('Note is required'),
            consultNoteDocuments: yup
                .array()
                .of(
                    yup
                        .mixed()
                        .test(
                            'fileType',
                            'Only PDF files are allowed',
                            (file: File | null) => {
                                return !file || file.type === 'application/pdf';
                            }
                        )
                )
                .nullable(),
        }),
        enableReinitialize: true,
        onSubmit: async (values, { resetForm, setSubmitting }) => {
            const formData = new FormData();
            formData.append('title', values.title);
            formData.append('consultNotes', values.consultNotes);
            values.consultNoteDocuments.forEach((file) =>
                formData.append('consultNoteDocuments', file)
            );
            await addConsultNote({ referralId, payload: formData })
                .then((response: any) => {
                    onClose(); // Close modal after successful save
                    refetch();
                    resetForm();
                    success(response?.message);
                })
                
                .catch((error) => {
                    failed(error?.response?.data?.message);
                })
                .finally(() => setSubmitting(false));
        },
    });

    const handleImageChange = (event: any) => {
        const files = Array.from(event.target.files, (v) => v);
        formik.setFieldValue('consultNoteDocuments', files);
        event.target.value = '';
    };
    // Handle file removal
    const handleRemoveFile = (fileToRemove: File) => {
        const updatedFiles = formik.values.consultNoteDocuments.filter(
            (file) => file !== fileToRemove
        );
        formik.setFieldValue('consultNoteDocuments', updatedFiles); // Update Formik state
    };

    return (
        <Dialog
            open={isOpen}
            onClose={onClose}
            disableEscapeKeyDown={true}
            fullWidth
        >
            <DialogTitle>
                Add Consult note
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <DialogContent>
                <form onSubmit={formik.handleSubmit}>
                    <TextInput
                        keyField={'title'}
                        label={'Title'}
                        formik={formik}
                        placeholder={'Title'}
                    />
                    <TextArea
                        keyField={'consultNotes'}
                        label={'Consult note'}
                        formik={formik}
                        outerDivStyle={{ width: '100%', marginTop: '10px' }}
                        placeholder={'Consult note...'}
                    />
                    <div className="main-fields upload-div">
                        <MuiButton
                            component="label"
                            role={undefined}
                            variant="contained"
                            tabIndex={-1}
                            startIcon={<CloudUploadIcon />}
                        >
                            Upload files
                            <VisuallyHiddenInput
                                type="file"
                                multiple
                                accept="application/pdf"
                                onChange={handleImageChange}
                            />
                        </MuiButton>
                    </div>
                    {formik.values.consultNoteDocuments?.length > 0 ? (
                        <Stack
                            direction="row"
                            spacing={1}
                            className="file-list"
                            style={{ display: 'flex', flexWrap: 'wrap' }}
                        >
                            {formik.values.consultNoteDocuments?.map(
                                (file, index) => (
                                    <Chip
                                        key={index}
                                        color="primary"
                                        variant="outlined"
                                        label={file.name}
                                        onDelete={() => handleRemoveFile(file)}
                                    />
                                )
                            )}
                        </Stack>
                    ) : null}
                    <DialogActions>
                        <Button
                            variant="secondary"
                            onClick={onClose}
                            disabled={formik.isSubmitting}
                        >
                            Cancel
                        </Button>
                        <Button type="submit" isLoading={formik.isSubmitting}>
                            Save
                        </Button>
                    </DialogActions>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default AddConsultNote;
