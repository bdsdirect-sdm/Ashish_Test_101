import React from 'react';
import {
    Chip,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    Stack,
    Button as MuiButton,
} from '@mui/material';
import * as yup from 'yup';
import { Close, CloudUpload } from '@mui/icons-material';
import Button from '@components/Common/Button';
import { patientReadyToReturn } from '../../API/Patient';
import { useNavigate } from 'react-router-dom';
import { failed, success } from '@components/Common/Toastify';
import TextArea from '@components/Common/TextArea';
import { useFormik } from 'formik';
import { addConsultNote } from '../../API/ConsultNote';
import { VisuallyHiddenInput } from './AddConsultNote';

interface Props {
    userId: string;
    referralId: number;
    isOpen: boolean;
    onClose: () => void;
}

const ConfirmReturnModal = ({ userId, referralId, isOpen, onClose }: Props) => {
    const navigate = useNavigate();

    const formik = useFormik({
        initialValues: {
            title: 'Referral Completed',
            consultNotes: '',
            consultNoteDocuments: [] as File[],
        },
        validationSchema: yup.object({
            title: yup.string(),
            consultNotes: yup.string(),
        }),
        enableReinitialize: true,
        onSubmit: async (values) => {
            await patientReadyToReturn(userId)
                .then(async (res: any) => {
                    if (
                        values.consultNotes ||
                        values.consultNoteDocuments.length > 0
                    ) {
                        const formData = new FormData();
                        formData.append('title', values.title);
                        formData.append('consultNotes', values.consultNotes);
                        values.consultNoteDocuments.forEach((file) =>
                            formData.append('consultNoteDocuments', file)
                        );
                        await addConsultNote({
                            referralId,
                            payload: formData,
                        }).catch((error) => {
                            failed(error?.response?.data?.message);
                        });
                    }
                    navigate('/app/patient');
                    success(res.message);
                })
                .catch((err) => {
                    failed(err.response.data.message);
                });
        },
    });

    const handleImageChange = (event: any) => {
        const files = Array.from(event.target.files, (v) => v);
        formik.setFieldValue('consultNoteDocuments', files);
        event.target.value = '';
    };
    // Handle file removal
    const handleRemoveFile = (fileToRemove: File) => {
        const updatedFiles = formik.values.consultNoteDocuments.filter(
            (file) => file !== fileToRemove
        );
        formik.setFieldValue('consultNoteDocuments', updatedFiles); // Update Formik state
    };

    return (
        <Dialog open={isOpen} onClose={onClose} fullWidth>
            <DialogTitle>
                Return to Referring Provider
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <Close />
                </IconButton>
            </DialogTitle>
            <DialogContent>
                Are you sure, you want to return this Patient.
                <form onSubmit={formik.handleSubmit}>
                    <TextArea
                        keyField={'consultNotes'}
                        label={null}
                        required={false}
                        formik={formik}
                        outerDivStyle={{ width: '100%', marginTop: '20px' }}
                        placeholder={'Consult note...'}
                    />
                    <div className="main-fields upload-div">
                        <MuiButton
                            component="label"
                            role={undefined}
                            variant="contained"
                            tabIndex={-1}
                            startIcon={<CloudUpload />}
                        >
                            Upload files
                            <VisuallyHiddenInput
                                type="file"
                                multiple
                                accept="application/pdf"
                                onChange={handleImageChange}
                            />
                        </MuiButton>
                    </div>
                    {formik.values.consultNoteDocuments?.length > 0 ? (
                        <Stack
                            direction="row"
                            spacing={1}
                            className="file-list"
                            style={{ display: 'flex', flexWrap: 'wrap' }}
                        >
                            {formik.values.consultNoteDocuments?.map(
                                (file, index) => (
                                    <Chip
                                        key={index}
                                        color="primary"
                                        variant="outlined"
                                        label={file.name}
                                        onDelete={() => handleRemoveFile(file)}
                                    />
                                )
                            )}
                        </Stack>
                    ) : null}
                    <DialogActions>
                        <Button type="submit" isLoading={formik.isSubmitting}>
                            Submit
                        </Button>
                    </DialogActions>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default ConfirmReturnModal;
