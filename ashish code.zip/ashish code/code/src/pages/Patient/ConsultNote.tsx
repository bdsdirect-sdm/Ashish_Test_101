import React from 'react';
import Button from '@components/Common/Button';
import { Add, ChevronLeft, ExpandMore } from '@mui/icons-material';
import { useLocation, useNavigate } from 'react-router-dom';
import './view-patient.css';
import {
    Accordion,
    AccordionDetails,
    AccordionSummary,
    Skeleton,
    Typography,
} from '@mui/material';
import { usePaitentConsultNotes } from '../../API/ConsultNote';
import { useModalDisclosure } from '@hooks/useDisclosure';
import AddConsultNote from './AddConsultNote';
import { Note } from '@typing/global';
import dayjs from 'dayjs';
import { useAppContext } from '../../contexts/AppContextProvider';
import { ViewDocument } from './AddPatient';
import { decryptData } from '@utils/EncryptDecrypt/EncryptDecrypt';

const ConsultNote = () => {
    const navigate = useNavigate();
    const { state } = useLocation();
    const [expanded, setExpanded] = React.useState<number | false>(0);
    const { isOpen, close, open } = useModalDisclosure();
    const viewDocModal = useModalDisclosure();
    const {
        value: { user },
    } = useAppContext();
    const IsMD = user?.doctorType === 'MD';
    const referralId = state?.referralId;
    const patientName = state?.fullName || '-';
    const doctorName = IsMD
        ? state?.referedBy?.name
        : state?.referedTo?.name || '-';

    const { isLoading, isFetching, data, refetch } = usePaitentConsultNotes({
        referralId,
    });

    const handleChange =
        (panel: number) =>
        (event: React.SyntheticEvent, isExpanded: boolean) => {
            setExpanded(isExpanded ? panel : false);
        };

    return (
        <>
            <div className="main-view-div">
                <div className="view-heading">
                    <div
                        onClick={() => navigate(-1)}
                        style={{ cursor: 'pointer' }}
                    >
                        <ChevronLeft />
                        <h4>Consult Notes</h4>
                    </div>
                    <div>
                        {IsMD ? (
                            <Button startIcon={<Add />} onClick={open}>
                                Add New
                            </Button>
                        ) : null}
                    </div>
                </div>
                <div
                    className="view-details"
                    style={{
                        display: 'flex',
                        gap: '2rem',
                        marginBottom: '10px',
                    }}
                >
                    <div>
                        Patient Name:{' '}
                        <b style={{ textTransform: 'capitalize' }}>
                            {decryptData(patientName)}
                        </b>
                    </div>
                    <div>
                        {IsMD ? 'Referred By' : 'Referred To'}:{' '}
                        <b style={{ textTransform: 'capitalize' }}>
                            {doctorName}
                        </b>
                    </div>
                </div>
                <div className="view-details">
                    {isLoading || isFetching ? (
                        <Skeleton height={100} animation="wave" />
                    ) : data?.length > 0 ? (
                        data?.map((note: Note, index: number) => (
                            <Accordion
                                key={index}
                                expanded={expanded === index}
                                onChange={handleChange(index)}
                            >
                                <AccordionSummary
                                    expandIcon={<ExpandMore />}
                                    aria-controls="panel1bh-content"
                                    id="1bh-header"
                                >
                                    <Typography
                                        sx={{
                                            textTransform: 'capitalize',
                                            width: '100%',
                                            fontWeight: '500',
                                        }}
                                    >
                                        {note.title}
                                    </Typography>
                                    <Typography sx={{ textWrap: 'nowrap' }}>
                                        {dayjs(note.updatedAt).format(
                                            'MMM DD YYYY'
                                        )}
                                    </Typography>
                                </AccordionSummary>
                                <AccordionDetails>
                                    {note.consultNotes}
                                    <div
                                        style={{
                                            display:
                                                note.ConsultNoteDocuments
                                                    .length > 0
                                                    ? 'block'
                                                    : 'none',
                                        }}
                                    >
                                        <h4 style={{ marginTop: '1rem' }}>
                                            Attached documents:
                                        </h4>
                                        {note.ConsultNoteDocuments?.map(
                                            (doc, index) => (
                                                <div
                                                    key={index}
                                                    style={{
                                                        cursor: 'pointer',
                                                        color: 'rgb(25, 118, 210)',
                                                        textDecoration:
                                                            'underline',
                                                        marginTop: '0.5rem',
                                                    }}
                                                    onClick={() =>
                                                        viewDocModal.open({
                                                            ...doc,
                                                            type: 'pdf',
                                                        })
                                                    }
                                                >
                                                    {doc?.name}
                                                </div>
                                            )
                                        )}
                                    </div>
                                </AccordionDetails>
                            </Accordion>
                        ))
                    ) : (
                        'Consult notes not available'
                    )}
                </div>
            </div>
            <AddConsultNote
                isOpen={isOpen}
                referralId={referralId}
                onClose={close}
                refetch={refetch}
            />
            <ViewDocument
                isOpen={viewDocModal.isOpen}
                data={viewDocModal.data}
                onClose={viewDocModal.close}
            />
        </>
    );
};

export default ConsultNote;
