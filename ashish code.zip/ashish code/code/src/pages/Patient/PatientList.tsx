import React, { useRef, useState } from 'react';
import '../Dashboard/style.css';
import './style.css';
import CustomTable from '@components/Common/table/CustomTable';
import { TableDataFields, TableHeadCells } from './constant';
import { defaultParams } from '@utils/global.constants';
import { Add as AddIcon, Clear, SearchRounded } from '@mui/icons-material';
import Button from '@components/Common/Button';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAppContext } from '../../contexts/AppContextProvider';
import { deletePatient, usePatients } from '../../API/Patient';
import { TableActionsMethod } from '@typing/global';
import { failed, success } from '@components/Common/Toastify';
import { IconButton } from '@mui/material';
import AddConsultNote from './AddConsultNote';
import { useModalDisclosure } from '@hooks/useDisclosure';
import dayjs from 'dayjs';

function PatientList() {
    const navigate = useNavigate();
    const location = useLocation();
    const {
        value: { user },
        handleLoading,
    } = useAppContext();
    const IsOD = user?.doctorType === 'OD';
    const statusType = location?.state?.statusType || [];
    const [params, setParams] = useState(defaultParams);
    const timeOutId = useRef(null);
    const {
        isOpen,
        close,
        open,
        data: consultNoteData,
        setData: setConsultNoteData,
    } = useModalDisclosure();

    const { isLoading, isFetching, data, refetch } = usePatients({
        params: { ...params, statusType },
    });

    const handleParamsChange = (key: string, value: string | number) => {
        setParams({ ...params, [key]: value });
    };

    const handleTableActions = ({ action, data }: TableActionsMethod) => {
        switch (action) {
            case 'view':
                navigate('/app/view-patient', { state: data });
                break;
            case 'edit':
                navigate('/app/edit-patient', { state: data });
                break;
            case 'delete':
                handleLoading(true);
                deletePatient({ id: data.id })
                    .then((res) => {
                        refetch();
                        success(res.message);
                    })
                    .catch((err) => {
                        failed(err.response.data.message);
                    })
                    .finally(() => handleLoading(false));
                break;
            case 'consultNote':
                open();
                setConsultNoteData(data);
                break;
            default:
                break;
        }
    };

    const handleKeyPress = (e: any) => {
        if (e.key === 'Enter') {
            refetch(); // Trigger the search function when Enter is pressed
        }
    };

    const handleClear = () => {
        setParams({ ...params, search: '' });
        timeOutId.current = setTimeout(() => {
            clearTimeout(timeOutId.current);
            refetch();
        }, 200);
    };

    return (
        <>
            <div className="main-dashboard-div">
                <div className="cards-wrapper">
                    <div className="heading-dashboard">
                        <h2>Referred Patients</h2>
                        {IsOD ? (
                            <Button
                                startIcon={<AddIcon />}
                                onClick={() => navigate('/app/add-patient')}
                            >
                                Add Referral Patient
                            </Button>
                        ) : null}
                    </div>
                    <div className="search-box">
                        <input
                            type="text"
                            placeholder="Search"
                            className="search-input"
                            value={params.search}
                            onChange={(e) =>
                                handleParamsChange('search', e.target.value)
                            }
                            onKeyDown={handleKeyPress} // Listen for the Enter key
                        />
                        <IconButton
                            type="button"
                            sx={{
                                p: '10px',
                                display:
                                    params.search.length > 0 ? 'flex' : 'none',
                            }}
                            aria-label="search"
                            onClick={handleClear}
                        >
                            <Clear />
                        </IconButton>
                        <Button
                            startIcon={<SearchRounded />}
                            onClick={() => refetch()}
                        >
                            Search
                        </Button>
                    </div>

                    <CustomTable
                        tableData={data?.listing || []}
                        headCells={TableHeadCells(IsOD)}
                        dataFields={TableDataFields}
                        selectedUserAction={handleTableActions}
                        canEdit={IsOD}
                        canDelete={IsOD}
                        loading={isLoading}
                        fetching={isFetching}
                        totalPages={data?.totalPages || 0}
                        currentPage={data?.currentPage || 0}
                        handlePageChange={(page) =>
                            page !== data?.currentPage &&
                            handleParamsChange('page', page)
                        }
                        handleSort={(sortKeyOrder) => {
                            setParams({ ...params, ...sortKeyOrder });
                        }}
                    />
                </div>
            </div>
            <AddConsultNote
                isOpen={isOpen}
                title={`${consultNoteData?.appointmentType} (${dayjs(
                    consultNoteData?.[
                        consultNoteData?.appointmentType === 'Consultation'
                            ? 'consultationAppointment'
                            : 'surgeryAppointment'
                    ]?.date
                ).format('MM-DD-YYYY')})`}
                referralId={consultNoteData?.referralId}
                onClose={close}
                refetch={refetch}
            />
        </>
    );
}

export default PatientList;
