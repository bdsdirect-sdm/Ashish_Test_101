import React from 'react';
import './view-patient.css';
import Button from '@components/Common/Button';
import { Add as AddIcon, ChevronLeft } from '@mui/icons-material';
import { useAppContext } from '../../contexts/AppContextProvider';
import { useLocation, useNavigate } from 'react-router-dom';
import { useMedicalDocuments, usePatientsById } from '../../API/Patient';
import { FullPageSpinner } from '@components/Common/Spinner/FullPageSpinner';
import dayjs from 'dayjs';
import { useModalDisclosure } from '@hooks/useDisclosure';
import ConfirmReturnModal from './ConfirmReturnModal';
import { HtmlParser } from '@utils/format';

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { statusColor } from '@utils/global.constants';
import { bookingStatusType } from '@typing/global';
import { MedicalDocument, ViewDocument } from './AddPatient';
import { decryptData } from '@utils/EncryptDecrypt/EncryptDecrypt';

const ViewPatient = () => {
    const navigate = useNavigate();
    const { state } = useLocation();
    const {
        value: { user },
    } = useAppContext();
    const { isLoading, data } = usePatientsById({
        id: state?.id, // patient's User Id
    });
    const { data: medicalDocuments } = useMedicalDocuments({
        id: state?.patientId,
    });

    const { isOpen, toggle } = useModalDisclosure();
    const viewDocModal = useModalDisclosure();
    const IsMD = user?.doctorType === 'MD';
    const IsNotCompleted = state?.bookingStatus !== 'completed';

    if (isLoading) return <FullPageSpinner />;

    // Decrypt data before displaying
      const decryptedData = {
          fullName: data?.fullName ? decryptData(data.fullName) : '',
          email: data?.email ? decryptData(data.email) : '',
          dob: data?.dob ? decryptData(data.dob) : '',
          phoneNumber: data?.phoneNumber ? decryptData(data.phoneNumber) : '',
      };

    return (
        <>
            <div className="main-view-div">
                <div className="view-heading">
                    <div
                        onClick={() => navigate(-1)}
                        style={{ cursor: 'pointer' }}
                    >
                        <ChevronLeft />
                        <h4>Back</h4>
                    </div>
                    {IsMD && IsNotCompleted ? (
                        <div>
                            <Button
                                startIcon={<AddIcon />}
                                onClick={() =>
                                    navigate('/app/add-appointment', {
                                        state: { patientUserId: state?.id },
                                    })
                                }
                            >
                                Add Appointment
                            </Button>
                            <Button
                                startIcon={<AddIcon />}
                                onClick={() => navigate('/app/add-patient')}
                            >
                                Add Referral Patient
                            </Button>
                        </div>
                    ) : null}
                </div>
                <div className="view-details">
                    <h4>Basic Information</h4>
                    <div className="profile-inner-wrapper">
                        <div className="profile-inputs">
                            <div className="d-flex name-fields">
                                <h4>Name: </h4>
                                <p style={{ textTransform: 'capitalize' }}>
                                    {decryptedData?.fullName}
                                </p>
                            </div>
                            <div className="d-flex name-fields">
                                <h4>Gender: </h4>
                                <p style={{ textTransform: 'capitalize' }}>
                                    {data?.gender}
                                </p>
                            </div>
                            <div className="d-flex name-fields">
                                <h4>DOB :</h4>
                                <p>{decryptedData?.dob}</p>
                            </div>
                        </div>
                        <div className="profile-inputs">
                            <div className="d-flex name-fields">
                                <h4>Phone: </h4>
                                <p>{decryptedData?.phoneNumber}</p>
                            </div>
                            <div className="d-flex name-fields">
                                <h4>Email: </h4>
                                <p>{decryptedData?.email}</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="view-details">
                    <h4>Reason of consult</h4>
                    <div className="profile-inner-wrapper">
                        <div className="profile-inputs">
                            <div className="d-flex name-fields">
                                <h4>Reason: </h4>
                                <p style={{ textTransform: 'capitalize' }}>
                                    {data?.consultReason?.reason}
                                </p>
                            </div>
                            <div className="d-flex name-fields">
                                <h4>Laterality: </h4>
                                <p style={{ textTransform: 'capitalize' }}>
                                    {data?.consultReason?.laterality}
                                </p>
                            </div>
                            <div className="d-flex name-fields">
                                <h4>Timing :</h4>
                                <p style={{ textTransform: 'capitalize' }}>
                                    {data?.consultReason?.timings}
                                </p>
                            </div>
                        </div>
                        <div className="profile-inputs">
                            <div className="d-flex name-fields">
                                <h4>Patient will return: </h4>
                                <p>
                                    {data?.consultReason?.patientReturn
                                        ? 'Yes'
                                        : 'No'}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="view-details">
                    <h4>Referral {IsMD ? 'By' : 'To'}</h4>
                    <div className="profile-inner-wrapper">
                        <div className="profile-inputs">
                            <div className="d-flex name-fields">
                                <h4>Doctor Name: </h4>
                                <p style={{ textTransform: 'capitalize' }}>
                                    {IsMD
                                        ? data?.referedBy.name
                                        : data?.referedTo.name}
                                </p>
                            </div>
                            {IsMD ? null : (
                                <div
                                    className="d-flex name-fields"
                                    style={{ width: '60%' }}
                                >
                                    <h4>Location: </h4>
                                    <p style={{ textTransform: 'capitalize' }}>
                                        {data?.address?.addressTitle}
                                        {', '}
                                        {data?.address?.city}
                                    </p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                <div className="view-details">
                    <h4>Insurance Details</h4>
                    <div className="profile-inner-wrapper">
                        <div className="profile-inputs">
                            <div className="d-flex name-fields">
                                <h4>Company Name: </h4>
                                <p style={{ textTransform: 'capitalize' }}>
                                    {data?.insurance?.companyName}
                                </p>
                            </div>
                            <div className="d-flex name-fields">
                                <h4>Company Plan: </h4>
                                <p style={{ textTransform: 'capitalize' }}>
                                    {data?.insurancePlan?.Plan}
                                </p>
                            </div>
                            {/*<div className="d-flex name-fields">
                                <h4>Policy Start Date: </h4>
                                <p>
                                    {dayjs(data?.insuranceStartDate).format(
                                        'MM-DD-YYYY'
                                    )}
                                </p>
                            </div>
                            <div className="d-flex name-fields">
                                <h4>Policy Expiry Date: </h4>
                                <p>
                                    {dayjs(data?.insuranceEndDate).format(
                                        'MM-DD-YYYY'
                                    )}
                                </p>
                            </div>*/}
                        </div>
                    </div>
                </div>
                {medicalDocuments?.length > 0 ? (
                    <div className="view-details">
                        <h4>Medical Documents</h4>
                        <div className="profile-inner-wrapper">
                            <div>
                                {medicalDocuments?.map(
                                    (file: File, index: number) => (
                                        <MedicalDocument
                                            file={file}
                                            key={index}
                                            onClick={() =>
                                                viewDocModal?.open(file)
                                            }
                                        />
                                    )
                                )}
                            </div>
                        </div>
                    </div>
                ) : null}

                <div className="view-details">
                    <h4>Notes</h4>
                    <div className="profile-inner-wrapper">
                        <div>
                            {data?.notes ? HtmlParser(data?.notes) : 'no data'}
                        </div>
                    </div>
                </div>
                {/* Appointment */}
                <div className="view-details">
                    <h4 style={{ marginBottom: '20px' }}>
                        Appointment History
                    </h4>
                    <TableContainer component={Paper}>
                        <Table sx={{ minWidth: 650 }} aria-label="simple table">
                            <TableHead>
                                <TableRow>
                                    <TableCell>Type</TableCell>
                                    <TableCell>Date</TableCell>
                                    <TableCell>Status</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {data?.appointment?.length > 0 ? (
                                    data?.appointment?.map(
                                        (appointment: any) => (
                                            <TableRow
                                                key={appointment?.id}
                                                sx={{
                                                    '&:last-child td, &:last-child th':
                                                        {
                                                            border: 0,
                                                        },
                                                }}
                                            >
                                                <TableCell
                                                    scope="row"
                                                    align="center"
                                                    style={{
                                                        textTransform:
                                                            'capitalize',
                                                    }}
                                                >
                                                    {appointment?.appointmentType ||
                                                        '-'}
                                                </TableCell>
                                                <TableCell align="center">
                                                    {appointment?.date
                                                        ? dayjs(
                                                              appointment.date
                                                          ).format('MM-DD-YYYY')
                                                        : '-'}
                                                </TableCell>
                                                <TableCell
                                                    align="center"
                                                    style={{
                                                        display: 'flex',
                                                        justifyContent:
                                                            'center',
                                                    }}
                                                >
                                                    <div
                                                        style={{
                                                            width: '35%',
                                                            padding: '4px 1px',
                                                            textTransform:
                                                                'capitalize',
                                                            borderRadius: '8px',
                                                            background:
                                                                statusColor[
                                                                    appointment.appointmentStatus as bookingStatusType
                                                                ],
                                                        }}
                                                    >
                                                        {appointment.appointmentStatus ||
                                                            '-'}
                                                    </div>
                                                </TableCell>
                                            </TableRow>
                                        )
                                    )
                                ) : (
                                    <TableRow>
                                        <TableCell
                                            colSpan={3}
                                            sx={{ textAlign: 'center' }}
                                        >
                                            No records
                                        </TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    {IsMD && IsNotCompleted ? (
                        //&& data?.consultReason?.patientReturn
                        <div className="return-patient">
                            <span onClick={toggle}>
                                Return to Referring Provider
                            </span>
                        </div>
                    ) : null}
                </div>
            </div>
            <ConfirmReturnModal
                userId={state?.id}
                referralId={state?.referralId}
                isOpen={isOpen}
                onClose={toggle}
            />
            <ViewDocument
                isOpen={viewDocModal.isOpen}
                data={viewDocModal.data}
                onClose={viewDocModal.close}
            />
        </>
    );
};

export default ViewPatient;
