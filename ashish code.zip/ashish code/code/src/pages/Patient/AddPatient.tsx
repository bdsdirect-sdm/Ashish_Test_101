import React, { useMemo } from 'react';
import './style.css';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import { useFormik } from 'formik';
import TextInput from '@components/Common/TextInput';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import DateSelector from '@components/Common/DateSelector';
import SelectFiled from '@components/Common/SelectFiled';
import uploadimg from '@images/PDF.svg';
import { formikIntialAndValidations } from './constant';
import {
    Dialog,
    DialogContent,
    DialogTitle,
    IconButton,
    Button as MuiButton,
    styled,
} from '@mui/material';
import Button from '@components/Common/Button';
import {
    addPatientReferral,
    addPatientReferralAsDraft,
    editPatientReferral,
    useMedicalDocuments,
} from '../../API/Patient';
import { useLocation, useNavigate } from 'react-router-dom';
import { failed, success } from '@components/Common/Toastify';
import { useInsurances } from '../../API/Insurance';
import {
    useDoctorsOnlyWithAddresses,
    useDoctorsAddresses,
} from '../../API/Doctor';
import ToggleSwitch from '@components/Common/ToggleSwitch';
import dayjs from 'dayjs';
import TextArea from '@components/Common/TextArea';
import SearchSelectField from '@components/Common/SearchSelectField';
import { Insurances } from '@typing/global';
import { formatFileSize } from '@utils/format';
import { useModalDisclosure } from '@hooks/useDisclosure';
import { Close } from '@mui/icons-material';

const VisuallyHiddenInput = styled('input')({
    clip: 'rect(0 0 0 0)',
    clipPath: 'inset(50%)',
    height: 1,
    overflow: 'hidden',
    position: 'absolute',
    bottom: 0,
    left: 0,
    whiteSpace: 'nowrap',
    width: 1,
});

interface Props {
    isEdit?: boolean;
}

function AddPatient({ isEdit = false }: Props) {
    const navigate = useNavigate();
    const location = useLocation();
    const { isOpen, close, open, data } = useModalDisclosure();

    const formik = useFormik({
        ...formikIntialAndValidations(isEdit ? location.state : null),
        onSubmit: (values: any, actions) => {
            const formData = new FormData();
            Object.keys(values).forEach((key) => {
                const val = values[key];
                if (key === 'medicalDocuments') {
                    // Append each file in the array with the same key
                    val.forEach((file: Blob) => {
                        formData.append('medicalDocuments', file);
                    });
                } else {
                    formData.append(key, val);
                }
            });
            (isEdit
                ? editPatientReferral(location.state?.id, formData)
                : addPatientReferral(formData)
            )
                .then((res: any) => {
                    navigate('/app/patient');
                    success(res.message);
                })
                .catch((err) => {
                    failed(err.response.data.message);
                })
                .finally(() => actions.setSubmitting(false));
        },
    });

    const { data: insurancesList, isLoading: isInsurancesLoading } =
        useInsurances({ params: {} });
    const { data: doctorsAddressesList, isLoading: isDoctorsAddressesLoading } =
        useDoctorsAddresses({
            doctorId: formik.values.referedTo,
            config: {
                onSuccess: (data) => {
                    if (data?.length === 1) {
                        formik.setFieldValue('location', data?.[0]?.id);
                    }
                },
            },
        }); // doctor's id from doctor table
    const { data: doctorsList, isLoading: isDoctorsLoading } =
        useDoctorsOnlyWithAddresses({ search: '' });

    const { data: medicalDocuments } = useMedicalDocuments({
        id: isEdit ? location?.state?.patientId : null,
    });

    const handleSaveAsDraft = () => {
        addPatientReferralAsDraft(formik.values)
            .then((res: any) => {
                navigate('/app/patient');
                success(res.message);
            })
            .catch((err) => {
                failed(err.response.data.message);
            });
    };

    const handleImageChange = (event: any) => {
        const docs = Array.from(event.target.files, (v) => v);
        formik.setFieldValue('medicalDocuments', docs);
        event.target.value = '';
    };

    const handleFormChange = (event: any) => {
        switch (event.target.name) {
            case 'referedTo':
                formik.setFieldValue('location', '');
                break;
            default:
                break;
        }
    };

    const doctorsSearchList = useMemo(() => {
        return (
            doctorsList?.map((item: any) => ({
                label: item.User.fullName,
                id: item.id,
            })) || []
        );
    }, [doctorsList]);

    const insurancesSearchList = useMemo(() => {
        return (
            insurancesList?.map((item: any) => ({
                label: item.companyName,
                id: item.id,
            })) || []
        );
    }, [insurancesList]);

    const insurancePlansList = useMemo(() => {
        return insurancesList
            ?.filter(
                (insurance: Insurances) =>
                    insurance.id === formik.values.insuranceId
            )?.[0]
            ?.InsurancePlans?.map((data: { plan: string; id: number }) => ({
                name: `${data.plan}`,
                value: data.id,
            }));
    }, [formik.values.insuranceId, insurancesSearchList]);

    return (
        <>
            <div className="main-add-div">
                <div className="add-heading">
                    <ChevronLeftIcon
                        onClick={() => navigate(-1)}
                        style={{ cursor: 'pointer' }}
                    />
                    <h4>{isEdit ? 'Edit' : 'Add'} Referral Patient</h4>
                </div>
                <form
                    className="add-form"
                    onSubmit={formik.handleSubmit}
                    onChange={handleFormChange}
                >
                    {/* basic information */}
                    <div className="heading-referral">
                        <h4>Basic information</h4>
                    </div>
                    <div className="main-fields">
                        <DateSelector
                            keyField={'dob'}
                            label={'DOB'}
                            formik={formik}
                            minDate={dayjs().subtract(120, 'years')}
                            maxDate={dayjs()}
                        />
                        <TextInput
                            keyField={'email'}
                            label={'Email'}
                            formik={formik}
                            className="inputfield-text"
                            placeholder={'Email'}
                            disabled={isEdit}
                        />
                        <TextInput
                            keyField={'phoneNumber'}
                            label={'Phone Number'}
                            formik={formik}
                            type="phone"
                            placeholder={'Enter phone number'}
                        />
                    </div>
                    <div className="main-fields">
                        <TextInput
                            keyField={'firstName'}
                            label={'First Name'}
                            className="inputfield-text"
                            formik={formik}
                            placeholder={'Enter first name'}
                        />
                        <TextInput
                            keyField={'lastName'}
                            label={'Last Name'}
                            className="inputfield-text"
                            formik={formik}
                            required={false}
                            placeholder={'Enter Last name'}
                        />
                        <SelectFiled
                            keyField={'gender'}
                            label={'Gender'}
                            formik={formik}
                            options={[
                                { name: 'Male', value: 'male' },
                                { name: 'Female', value: 'female' },
                                { name: 'Other', value: 'other' },
                            ]}
                        />
                    </div>

                    {/* reason of consult */}
                    <div className="heading-referral">
                        <h4>Reason of consult</h4>
                    </div>
                    <div className="consult-div">
                        <SelectFiled
                            keyField={'reason'}
                            label={'Disease Name'}
                            formik={formik}
                            options={[
                                { name: 'Cataract', value: 'cataract' },
                                { name: 'Medical', value: 'medical' },
                                { name: 'Keratoconus', value: 'keratoconus' },
                                {
                                    name: 'Corneal, non-keratoconus',
                                    value: 'non-keratoconus',
                                },
                                { name: 'Other', value: 'other' },
                            ]}
                        />
                        <SelectFiled
                            keyField={'laterality'}
                            label={'Laterality'}
                            formik={formik}
                            options={[
                                { name: 'Left', value: 'left' },
                                { name: 'Right', value: 'right' },
                                { name: 'Both', value: 'bilateral' },
                            ]}
                        />
                        <div className="toggle-div">
                            <h4>Patient to return to your care afterwards</h4>
                            <div className="toggle-icon">
                                <p>No</p>
                                <ToggleSwitch
                                    name="patientReturn"
                                    formik={formik}
                                />
                                <p>Yes</p>
                            </div>
                        </div>
                    </div>
                    <div className="consult-div">
                        <SelectFiled
                            keyField={'timings'}
                            label={'Timing'}
                            formik={formik}
                            options={[
                                {
                                    name: 'Routine (Within 1 month)',
                                    value: 'routine',
                                },
                                {
                                    name: 'Urgent (Within 1 Week)',
                                    value: 'urgent',
                                },
                                {
                                    name: 'Emergent (within 24 hours or less)',
                                    value: 'emergent',
                                },
                            ]}
                        />
                    </div>

                    {/* refrral od/md */}
                    <div className="heading-referral">
                        <h4>Refer to</h4>
                    </div>
                    <div className="main-fields">
                        <SearchSelectField
                            keyField={'referedTo'} // Key field for formik to use
                            label={'MD Name'} // Label for the search select field
                            formik={formik} // Formik object to handle form data
                            isLoading={isDoctorsLoading} // Loading state for fetching doctors list
                            options={doctorsSearchList}
                        />
                        <SelectFiled
                            keyField={'location'}
                            label={'Add Location'}
                            formik={formik}
                            isLoading={isDoctorsAddressesLoading}
                            options={doctorsAddressesList?.map(
                                (data: {
                                    addressTitle: string;
                                    id: number;
                                    city: string;
                                }) => ({
                                    name: `${data.addressTitle}, ${data.city}`,
                                    value: data.id,
                                })
                            )}
                        />

                        {/*<SelectFiled
                        keyField={'speciality'}
                        label={'Speciality'}
                        formik={formik}
                        options={[
                            { name: 'Surgeon', value: 'md' },
                            { name: 'consultant', value: 'od' },
                        ]}
                    />*/}
                    </div>

                    {/* insurance details */}
                    <div className="heading-referral">
                        <h4>Insurance Details</h4>
                    </div>
                    <div className="main-fields">
                        <SearchSelectField
                            keyField={'insuranceId'}
                            label={'Company Name'}
                            formik={formik}
                            isLoading={isInsurancesLoading}
                            options={insurancesSearchList}
                        />
                        <SelectFiled
                            keyField={'insurancePlanId'}
                            label={'Insurance Plan'}
                            formik={formik}
                            isLoading={isInsurancesLoading}
                            options={insurancePlansList}
                        />
                    </div>

                    <div className="heading-referral">
                        <h4>Medical Documents</h4>
                    </div>
                    <div className="main-fields upload-div">
                        <MuiButton
                            component="label"
                            role={undefined}
                            variant="contained"
                            tabIndex={-1}
                            startIcon={<CloudUploadIcon />}
                        >
                            Upload files
                            <VisuallyHiddenInput
                                type="file"
                                multiple
                                accept=".pdf, .doc, .docx, .jpeg, .jpg, .png"
                                onChange={handleImageChange}
                            />
                        </MuiButton>
                    </div>
                    <div className="docs">
                        <p>pdf, doc, jpeg, png</p>
                    </div>

                    {formik.values.medicalDocuments?.length > 0 ||
                    (isEdit && medicalDocuments?.length > 0) ? (
                        <div className="upload-files-div">
                            {isEdit
                                ? medicalDocuments?.map(
                                      (file: File, index: number) => (
                                          <MedicalDocument
                                              file={file}
                                              key={index}
                                              onClick={() => open(file)}
                                          />
                                      )
                                  )
                                : null}
                            {formik.values.medicalDocuments.map(
                                (file: File, index: number) => (
                                    <MedicalDocument
                                        file={file}
                                        onClick={() => open(file)}
                                        key={index}
                                    />
                                )
                            )}
                        </div>
                    ) : null}

                    <div className="note-div">
                        <TextArea
                            keyField={'notes'}
                            label={'Notes'}
                            formik={formik}
                            required={false}
                        />
                    </div>

                    <div className="bottom-btn">
                        <div className="bottom-btn-group">
                            <div className="draft-btn">
                                <Button
                                    variant="secondary"
                                    disabled={!!formik?.isSubmitting}
                                    onClick={() => navigate(-1)}
                                >
                                    Cancel
                                </Button>
                                {isEdit ? null : (
                                    <Button
                                        variant="secondary"
                                        disabled={!!formik?.isSubmitting}
                                        onClick={handleSaveAsDraft}
                                    >
                                        Save as Draft
                                    </Button>
                                )}
                            </div>
                            <div className="patient-submit-btn">
                                <Button
                                    isLoading={formik.isSubmitting}
                                    type="submit"
                                    className="submit-btn"
                                >
                                    Submit
                                </Button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            {isOpen ? (
                <ViewDocument isOpen={isOpen} data={data} onClose={close} />
            ) : null}
        </>
    );
}

export default AddPatient;

export const MedicalDocument = ({
    file,
    onClick,
}: {
    file: File;
    onClick: () => void;
}) => {
    return (
        <div className="upload-files">
            <div className="pdf-img">
                <img src={uploadimg} alt="profile" className="" />
                <div className="file-content">
                    <h5 onClick={onClick}>{file.name}</h5>
                    {/*<p>2m ago</p>*/}
                </div>
            </div>
            <div className="file-size">
                <p>{formatFileSize(file.size)}</p>
            </div>
        </div>
    );
};

export const ViewDocument = ({
    isOpen,
    data,
    onClose,
}: {
    isOpen: boolean;
    data: any;
    onClose: () => void;
}) => {
    const type = data?.type || data?.name?.split('.')?.pop();

    const Viewer = () => {
        const getDocumentUrl = () => {
            if (typeof data === 'object' && data instanceof Blob) {
                return URL.createObjectURL(data);
            }
            return data?.documentUrl || '';
        };
        const documentUrl = getDocumentUrl();

        switch (type) {
            case 'pdf':
            case 'application/pdf':
                return (
                    <iframe
                        src={`${documentUrl}#toolbar=0`}
                        width="100%"
                        height="400px"
                    />
                );
            case 'doc':
            case 'docx':
            case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
            case 'application/msword':
                // If it's a Blob, show a download link; if it's a URL, use Google Docs Viewer
                return typeof data === 'object' && data instanceof Blob ? (
                    <a href={documentUrl} download="document.docx">
                        Click to download DOC/DOCX file
                    </a>
                ) : (
                    <iframe
                        src={`https://docs.google.com/viewer?url=${encodeURIComponent(
                            documentUrl
                        )}&embedded=true`}
                        width="100%"
                        height="400px"
                    />
                );
            default:
                return (
                    <img
                        src={documentUrl}
                        width="100%"
                        height="400px"
                        alt="Document preview"
                    />
                );
        }
    };

    return (
        <Dialog
            open={isOpen}
            onClose={onClose}
            disableEscapeKeyDown={true}
            fullWidth
        >
            <DialogTitle>
                {data?.name || 'View'}
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <Close />
                </IconButton>
            </DialogTitle>
            <DialogContent>
                <Viewer />
            </DialogContent>
        </Dialog>
    );
};
