import React, { useRef, useState } from 'react';
import './style.css';
import CustomTable from '@components/Common/table/CustomTable';
import { TableDataFields, TableHeadCells } from './constant';
import { deleteAppointment, useAppointments } from '../../API/Appointment';
import { defaultParams } from '@utils/global.constants';
import { useAppContext } from '../../contexts/AppContextProvider';
import Button from '@components/Common/Button';
import { Add as AddIcon, Clear, SearchRounded } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { TableActionsMethod } from '@typing/global';
import { failed, success } from '@components/Common/Toastify';
import { useModalDisclosure } from '@hooks/useDisclosure';
import { IconButton } from '@mui/material';
import UpdateStatusWithConsultNote from './UpdateStatusWithConsultNote';
import dayjs from 'dayjs';
import { decryptData } from '@utils/EncryptDecrypt/EncryptDecrypt';

function AppointmentList() {
    const navigate = useNavigate();
    const timeOutId = useRef(null);
    const {
        value: { user },
        handleLoading,
    } = useAppContext();
    const IsMD = user?.doctorType === 'MD';
    const { isOpen, open, close, data: modalData } = useModalDisclosure();

    const [params, setParams] = useState(defaultParams);

    const { isLoading, isFetching, data, refetch } = useAppointments({
        params,
        config: { keepPreviousData: true },
    });

    const handleParamsChange = (key: string, value: string | number) => {
        setParams({ ...params, [key]: value });
    };

    const handleTableActions = ({ action, data }: TableActionsMethod) => {
        switch (action) {
            case 'cancel':
                open({ ...data, actionType: 'cancel' });
                break;
            case 'complete':
                open({ ...data, actionType: 'complete' });
                break;
            case 'view':
                navigate('/app/view-appointment', { state: data });
                break;
            case 'edit':
                navigate('/app/edit-appointment', { state: data });
                break;
            case 'delete':
                handleLoading(true);
                deleteAppointment({ id: data.id })
                    .then((res) => {
                        refetch();
                        success(res.message);
                    })
                    .catch((err) => {
                        failed(err.response.data.message);
                    })
                    .finally(() => handleLoading(false));
                break;
            default:
                break;
        }
    };

    const handleKeyPress = (e: any) => {
        if (e.key === 'Enter') {
            refetch(); // Trigger the search function when Enter is pressed
        }
    };

    const handleClear = () => {
        setParams({ ...params, search: '' });
        timeOutId.current = setTimeout(() => {
            clearTimeout(timeOutId.current);
            refetch();
        }, 200);
    };
    const appointmentType = modalData?.appointmentType
        ? modalData?.appointmentType?.[0].toUpperCase() +
          modalData?.appointmentType.slice(1)
        : '';

    return (
        <>
            <UpdateStatusWithConsultNote
                isOpen={isOpen}
                title={`${
                    modalData?.actionType === 'complete' ? 'Complete' : 'Cancel'
                } Appointment`}
                consultNoteTitle={`${appointmentType} Appointment ${
                    modalData?.actionType === 'complete'
                        ? 'Completed'
                        : 'Canceled'
                } (${dayjs(modalData?.date).format('MM-DD-YYYY')})`}
                message={`Are you sure, want to ${
                    modalData?.actionType === 'complete' ? 'complete' : 'cancel'
                } the appointment with ${decryptData(modalData?.fullName) as string}.`}
                modalData={modalData}
                onClose={close}
                refetch={refetch}
            />
            <div className="main-dashboard-div">
                <div className="cards-wrapper">
                    <div className="heading-dashboard">
                        <h2>Appointment list</h2>
                        {IsMD ? (
                            <Button
                                startIcon={<AddIcon />}
                                onClick={() => navigate('/app/add-appointment')}
                            >
                                Add Appointment
                            </Button>
                        ) : null}
                    </div>
                    <div className="search-box">
                        <input
                            type="text"
                            placeholder="Search"
                            className="search-input"
                            value={params.search}
                            onChange={(e) =>
                                handleParamsChange('search', e.target.value)
                            }
                            onKeyDown={handleKeyPress} // Listen for the Enter key
                        />
                        <IconButton
                            type="button"
                            sx={{
                                p: '10px',
                                display:
                                    params.search.length > 0 ? 'flex' : 'none',
                            }}
                            aria-label="search"
                            onClick={handleClear}
                        >
                            <Clear />
                        </IconButton>
                        <Button
                            startIcon={<SearchRounded />}
                            onClick={() => refetch()}
                        >
                            Search
                        </Button>
                    </div>

                    <CustomTable
                        tableData={data?.listing || []}
                        headCells={TableHeadCells}
                        dataFields={TableDataFields}
                        selectedUserAction={handleTableActions}
                        loading={isLoading}
                        canDelete={false}
                        fetching={isFetching}
                        totalPages={data?.totalPages || 0}
                        currentPage={data?.currentPage || 0}
                        handlePageChange={(page) =>
                            page !== data?.currentPage &&
                            handleParamsChange('page', page)
                        }
                        handleSort={(sortKeyOrder) =>
                            setParams({ ...params, ...sortKeyOrder })
                        }
                    />
                </div>
            </div>
        </>
    );
}

export default AppointmentList;
