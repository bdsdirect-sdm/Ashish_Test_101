import React from 'react';
import './view.css';
import { ChevronLeft } from '@mui/icons-material';
import { useLocation, useNavigate } from 'react-router-dom';
import { HtmlParser } from '@utils/format';
import dayjs from 'dayjs';
import { decryptData } from '@utils/EncryptDecrypt/EncryptDecrypt';

const ViewAppointment = () => {
    const navigate = useNavigate();
    const { state } = useLocation();

    return (
        <>
            <div className="main-view-div">
                <div className="view-heading">
                    <div
                        onClick={() => navigate(-1)}
                        style={{ cursor: 'pointer' }}
                    >
                        <ChevronLeft />
                        <h4>Back</h4>
                    </div>
                </div>

                <div className="view-details">
                    <h4>Basic Information</h4>
                    <div className="profile-inner-wrapper">
                        <div className="profile-inputs">
                            <div className="d-flex name-fields">
                                <h4>Patient Name: </h4>
                                <p style={{ textTransform: 'capitalize' }}>
                                    {state?.fullName
                                        ? decryptData(state.fullName)
                                        : '-'}
                                </p>
                            </div>
                            <div className="d-flex name-fields">
                                <h4>Appointment Date: </h4>
                                <p style={{ textTransform: 'capitalize' }}>
                                    {state?.date
                                        ? dayjs(state?.date).format(
                                              'MM-DD-YYYY'
                                          )
                                        : '-'}
                                </p>
                            </div>
                            <div className="d-flex name-fields">
                                <h4>Type: </h4>
                                <p style={{ textTransform: 'capitalize' }}>
                                    {state?.appointmentType || '-'}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default ViewAppointment;
