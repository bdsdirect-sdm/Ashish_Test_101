import React, { useMemo } from 'react';
import './style.css';
import { useFormik } from 'formik';
import { ChevronLeft } from '@mui/icons-material';
import DateSelector from '@components/Common/DateSelector';
import SelectFiled from '@components/Common/SelectFiled';
import { formikIntialAndValidations } from './constant';
import Button from '@components/Common/Button';
import { useLocation, useNavigate } from 'react-router-dom';
import { failed, success } from '@components/Common/Toastify';
import { addAppointment, editAppointment } from '../../API/Appointment';
import dayjs from 'dayjs';
import SearchSelectField from '@components/Common/SearchSelectField';
import { useGetAllPatientsForAppointment } from '../../API/Patient';
import { decryptData } from '@utils/EncryptDecrypt/EncryptDecrypt';

interface Props {
    isEdit?: boolean;
}

function AddAppointment({ isEdit = false }: Props) {
    const navigate = useNavigate();
    const location = useLocation();
    const patientUserId = location.state?.patientUserId;

    const { isLoading, data } = useGetAllPatientsForAppointment({});

    const formik = useFormik({
        ...formikIntialAndValidations(
            isEdit ? location.state : { patientUserId }
        ),
        onSubmit: (values, actions) => {
            const referralId = data.find(
                (patient: any) => patient.userId === values.patientUserId
            ).referralId;
            const payload = { ...values, referralId };

            (isEdit
                ? editAppointment(location.state?.id, payload)
                : addAppointment(payload)
            )
                .then((res: any) => {
                    navigate('/app/appointment');
                    success(res.message);
                })
                .catch((err) => {
                    failed(err.response.data.message);
                })
                .finally(() => actions.setSubmitting(false));
        },
    });

    const patientList = useMemo(() => {
        return (
            data?.map((patient: any) => ({
                label: decryptData(patient.fullName), 
                id: patient.userId,
            })) || []
        );
    }, [data]);

    return (
            <div className="main-add-div">
                <div className="add-heading">
                    <ChevronLeft
                        onClick={() => navigate(-1)}
                        style={{ cursor: 'pointer' }}
                    />
                    <h4>{isEdit ? 'Edit' : 'Add'} Appointment</h4>
                </div>
                <form className="add-form" onSubmit={formik.handleSubmit}>
                    <div className="main-fields">
                        <SearchSelectField
                            label={'Patient Name'}
                            keyField={'patientUserId'}
                            formik={formik}
                        options={patientList}
                        isLoading={isLoading}
                        readOnly={isEdit}
                        defaultValue={parseInt(patientUserId)}
                    />
                    <DateSelector
                        label={'Appointment Date'}
                        keyField={'date'}
                        formik={formik}
                        minDate={dayjs()}
                        maxDate={dayjs().add(2, 'years')}
                    />
                    <SelectFiled
                        label={'Type'}
                        keyField={'appointmentType'}
                        formik={formik}
                        options={[
                            { name: 'Consultation', value: 'consultation' },
                            { name: 'Surgery', value: 'surgery' },
                        ]}
                    />
                </div>

                <div className="bottom-btn">
                    <div className="bottom-btn-group">
                        <Button
                            variant="secondary"
                            disabled={formik.isSubmitting}
                            onClick={() => navigate(-1)}
                        >
                            Cancel
                        </Button>
                        <Button
                            isLoading={formik.isSubmitting}
                            type="submit"
                            className="submit-btn"
                        >
                            Submit
                        </Button>
                    </div>
                </div>
            </form>
        </div>
    );
}

export default AddAppointment;
    