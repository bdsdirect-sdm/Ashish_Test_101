import dayjs from 'dayjs';
import * as yup from 'yup';

export const TableHeadCells = [
    {
        id: 'fullName',
        label: 'Patient name',
        sort: true,
        isEncrypted: true,
        nested: 'fullName',
        style: { textWrap: 'nowrap', textTransform: 'capitalize' },
    },
    {
        id: 'date',
        label: 'Date',
        sort: true,
        type: 'date',
        nested: 'date',
    },
    {
        id: 'appointmentType',
        sort: true,
        label: 'Type',
        nested: 'appointmentType',
        style: { textTransform: 'capitalize' },
    },
    {
        id: 'appointmentStatus',
        sort: true,
        label: 'Status',
        type: 'status',
        nested: 'appointmentStatus',
    },
    {
        id: 'completeBtn',
        label: 'Complete appointment',
        type: 'completeBtn',
        nested: 'appointmentStatus',
    },
    {
        id: 'cancelBtn',
        label: 'Cancel appointment',
        type: 'cancelBtn',
        nested: 'appointmentStatus',
    },
    {
        id: 'actions',
        label: 'Actions',
        style: { textAlign: 'center' },
    },
];
export const TableDataFields = [
    'fullName',
    'date',
    'appointmentType',
    'appointmentStatus',
    'completeBtn',
    'cancelBtn',
    'actions',
];

export const formikIntialAndValidations = (data: any) => {
    return {
        initialValues: {
            patientUserId: data?.patientUserId || '',
            date: data?.date ? dayjs(data?.date).format('MM-DD-YYYY') : '',
            appointmentType: data?.appointmentType || '',
        },
        validationSchema: yup.object({
            patientUserId: yup.string().required('Patient is required'),
            date: yup.string().required('Date is required'),
            appointmentType: yup
                .string()
                .required('Appointment Type is required'),
        }),
    };
};
