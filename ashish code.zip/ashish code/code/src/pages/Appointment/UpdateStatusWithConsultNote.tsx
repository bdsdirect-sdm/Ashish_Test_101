import React from 'react';
import * as yup from 'yup';
import {
    Chip,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    Button as MuiButton,
    Stack,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import './style.css';
import { failed, success } from '@components/Common/Toastify';
import Button from '@components/Common/Button';
import { useFormik } from 'formik';
import TextArea from '@components/Common/TextArea';
import { cancelAppointment, completeAppointment } from '../../API/Appointment';
import { addConsultNote } from '../../API/ConsultNote';
import { VisuallyHiddenInput } from '@pages/Patient/AddConsultNote';
import { CloudUpload } from '@mui/icons-material';

const UpdateStatusWithConsultNote = ({
    isOpen,
    modalData,
    title = null,
    consultNoteTitle = null,
    message = null,
    onClose,
    refetch,
}: {
    isOpen: boolean;
    modalData: any;
    title: string;
    consultNoteTitle: string;
    message: string;
    onClose: () => void;
    refetch: () => void;
}) => {
    const formik = useFormik({
        initialValues: {
            title: consultNoteTitle || '',
            consultNotes: '',
            consultNoteDocuments: [] as File[],
        },
        validationSchema: yup.object({
            title: yup.string(),
            consultNotes: yup.string(),
        }),
        enableReinitialize: true,
        onSubmit: (values, { resetForm, setSubmitting }) => {
            (modalData?.actionType === 'complete'
                ? completeAppointment
                : cancelAppointment)({ id: modalData.id })
                .then(async (res) => {
                    if (
                        values.consultNotes ||
                        values.consultNoteDocuments.length > 0
                    ) {
                        const formData = new FormData();
                        formData.append('title', values.title);
                        formData.append('consultNotes', values.consultNotes);
                        values.consultNoteDocuments.forEach((file) =>
                            formData.append('consultNoteDocuments', file)
                        );
                        await addConsultNote({
                            referralId: modalData.referralId,
                            payload: formData,
                        }).catch((error) => {
                            failed(error?.response?.data?.message);
                        });
                    }
                    onClose(); // Close modal after successful save
                    refetch();
                    resetForm();
                    success(res?.data?.data?.message);
                })
                .catch((err) => {
                    failed(err.response.data.message);
                })
                .finally(() => {
                    setSubmitting(false);
                });
        },
    });

    const handleImageChange = (event: any) => {
        const files = Array.from(event.target.files, (v) => v);
        formik.setFieldValue('consultNoteDocuments', files);
        event.target.value = '';
    };
    // Handle file removal
    const handleRemoveFile = (fileToRemove: File) => {
        const updatedFiles = formik.values.consultNoteDocuments.filter(
            (file) => file !== fileToRemove
        );
        formik.setFieldValue('consultNoteDocuments', updatedFiles); // Update Formik state
    };

    return (
        <Dialog
            open={isOpen}
            onClose={onClose}
            disableEscapeKeyDown={true}
            fullWidth
        >
            <DialogTitle>
                {title}
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <DialogContent>
                {message}
                <form onSubmit={formik.handleSubmit}>
                    <TextArea
                        keyField={'consultNotes'}
                        label={null}
                        formik={formik}
                        outerDivStyle={{ width: '100%', marginTop: '20px' }}
                        placeholder={'Consult note...'}
                    />
                    <div className="main-fields upload-div">
                        <MuiButton
                            component="label"
                            role={undefined}
                            variant="contained"
                            tabIndex={-1}
                            startIcon={<CloudUpload />}
                        >
                            Upload files
                            <VisuallyHiddenInput
                                type="file"
                                multiple
                                accept="application/pdf"
                                onChange={handleImageChange}
                            />
                        </MuiButton>
                    </div>
                    {formik.values.consultNoteDocuments?.length > 0 ? (
                        <Stack
                            direction="row"
                            spacing={1}
                            className="file-list"
                            style={{ display: 'flex', flexWrap: 'wrap' }}
                        >
                            {formik.values.consultNoteDocuments?.map(
                                (file, index) => (
                                    <Chip
                                        key={index}
                                        color="primary"
                                        variant="outlined"
                                        label={file.name}
                                        onDelete={() => handleRemoveFile(file)}
                                    />
                                )
                            )}
                        </Stack>
                    ) : null}
                    <DialogActions>
                        <Button
                            variant="secondary"
                            onClick={onClose}
                            disabled={formik.isSubmitting}
                        >
                            Cancel
                        </Button>
                        <Button type="submit" isLoading={formik.isSubmitting}>
                            Save
                        </Button>
                    </DialogActions>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default UpdateStatusWithConsultNote;
