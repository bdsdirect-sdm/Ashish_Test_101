import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import React from 'react';
import * as yup from 'yup';
import '../Profile/style.css';
import { failed, success } from '@components/Common/Toastify';
import TextInput from '@components/Common/TextInput';
import Button from '@components/Common/Button';
import { useFormik } from 'formik';
import SelectFiled from '@components/Common/SelectFiled';
import { addStaff, getStaffs } from '../../API/Staff/index';

const AddStaffModal = ({
    isOpen,
    onClose,
    onAddStaffRefetchList,
}: {
    isOpen: boolean;
    onClose: () => void;
    onAddStaffRefetchList: () => void;
}) => {
    const formik = useFormik({
        initialValues: {
            firstName: '',
            lastName: '',
            email: '',
            phoneNumber: '',
            gender: '',
        },
        validationSchema: yup.object({
            firstName: yup
                .string()
                .max(20)
                .required('First Name is required')
                .matches(/^$|^\S+.*/, 'Only blank spaces are not valid.'),
            lastName: yup
                .string()
                .max(20)
                .required('Last Name is required')
                .matches(/^$|^\S+.*/, 'Only blank spaces are not valid.'),
            email: yup.string().email().required('Email is required'),
            gender: yup.string().required('Gender is required'),
            phoneNumber: yup
                .string()
                .min(8, 'Minimum 8 numbers')
                .required('Phone Number is required'),
        }),
        onSubmit: (values, actions) => {
            addStaff(values)
                .then((response: any) => {
                    onClose(); // Close modal after successful save
                    success(response?.data?.message); // Show success toast
                    onAddStaffRefetchList();
                    actions.resetForm(); // Reset form fields after successful save
                })

                .catch((error) => {
                    failed(error?.response?.data?.message); // Show error toast
                })
                .finally(() => {
                    actions.setSubmitting(false); // Stop form submitting state
                });
        },
    });

    return (
        <Dialog
            open={isOpen}
            onClose={onClose}
            disableEscapeKeyDown={true}
            fullWidth={true}
        >
            <DialogTitle>
                Add Staff
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <DialogContent>
                <form onSubmit={formik.handleSubmit}>
                    <TextInput
                        keyField={'firstName'}
                        label={'First Name'}
                        className="inputfield-text"
                        formik={formik}
                        placeholder={'Enter first name'}
                    />
                    <TextInput
                        keyField={'lastName'}
                        label={'Last Name'}
                        className="inputfield-text"
                        formik={formik}
                        placeholder={'Enter last name'}
                    />
                    <SelectFiled
                        keyField={'gender'}
                        label={'Gender'}
                        formik={formik}
                        options={[
                            { name: 'Male', value: 'male' },
                            { name: 'Female', value: 'female' },
                            { name: 'Other', value: 'other' },
                        ]}
                    />
                    <TextInput
                        keyField={'email'}
                        label={'Email'}
                        formik={formik}
                        className="inputfield-text"
                        placeholder={'Email'}
                    />
                    <TextInput
                        keyField={'phoneNumber'}
                        label={'Phone Number'}
                        formik={formik}
                        type="phone"
                        placeholder={'Enter phone number'}
                    />
                    <DialogActions>
                        <Button variant="secondary" onClick={onClose}>
                            Cancel
                        </Button>
                        <Button type="submit" isLoading={formik.isSubmitting}>
                            Save
                        </Button>
                    </DialogActions>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default AddStaffModal;
