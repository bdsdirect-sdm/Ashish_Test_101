import React, { useEffect, useRef, useState } from 'react';
import '../Dashboard/style.css';
import './style.css';
import Button from '@components/Common/Button';
import { Add as AddIcon, Clear, SearchRounded } from '@mui/icons-material';
import { useModalDisclosure } from '@hooks/useDisclosure';
import AddStaffModal from './AddStaffModal';
import {
    DialogContent,
    IconButton,
    DialogActions,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    CircularProgress,
    Paper,
    Checkbox,
} from '@mui/material';
import { addDoctorStaff, getStaffs } from '../../API/Staff/index';
import { failed, success } from '@components/Common/Toastify';
import CustomPagination from '@components/Common/table/CustomPagination';

const StaffList = () => {
    const addStaffModal = useModalDisclosure();
    const [staffList, setStaffList] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [selectedStaff, setSelectedStaff] = useState<number[]>([]);
    const [saveLoading, setSaveLoading] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [filteredStaffList, setFilteredStaffList] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalCount, setTotalCount] = useState(0);
    const [isStaffChanged, setIsStaffChanged] = useState(false);
    const selectedStaffsCache = useRef(null)
    const rowsPerPage = 10

    useEffect(() => {
        // Fetch staff list on initial load, page change, or row-per-page change
        fetchStaffList();
    }, [currentPage, rowsPerPage]); // Removed searchQuery from dependencies

    const fetchStaffList = (search = '') => {
        setIsLoading(true);
        getStaffs({
            search, // Use the search parameter explicitly
            page: currentPage,
            limit: rowsPerPage,
        })
            .then((res: any) => {
                const staffData = res.data?.data?.listing || [];
                const doctorStaffs =
                    res.data?.data?.listing?.doctorStaffs || [];
                const allStaffs = res.data?.data?.listing?.allStaffs || [];
                const combinedStaffList = search
                    ? [...doctorStaffs, ...allStaffs]
                    : doctorStaffs;
                setStaffList(combinedStaffList);
                // Apply search filter if there is a search query
                const filteredList = combinedStaffList.filter((staff: any) =>
                    staff.fullName.toLowerCase().includes(search.toLowerCase())
                );
                setTotalCount(staffData?.totalCount);
                setFilteredStaffList(filteredList); // Set the filtered staff list
                const selectedDoctorIds = staffData?.doctorStaffs.map(
                    (staff: any) => staff.id
                );
                selectedStaffsCache.current = selectedDoctorIds;
                setSelectedStaff(selectedDoctorIds);
            })
            .catch((error) => {
                failed(error?.response?.data?.message); // Show error toast
            })
            .finally(() => {
                setIsLoading(false);
            });
    };

    const handleSearch = () => {
        // Call fetchStaffList with search query when the search button is clicked
        fetchStaffList(searchQuery);
    };

    const handleClearSearch = () => {
        setSearchQuery('');
        setFilteredStaffList(staffList);
        fetchStaffList(); // Clear the search filter and fetch all staff
    };

    const handleChangePage = (newPage: number) => {
        setCurrentPage(newPage);
    };

    const handleSelectChange = (id: number) => {
        const newStaffs = selectedStaff.includes(id)
            ? selectedStaff.filter((staffId) => staffId !== id)
            : [...selectedStaff, id];
        setSelectedStaff(newStaffs);
        setIsStaffChanged(
            JSON.stringify(selectedStaffsCache.current) !==
                JSON.stringify(newStaffs)
        );
     };

    const handleSave = () => {
        setSaveLoading(true);
        const uniqueStaffIds = Array.from(new Set(selectedStaff));

        const newStaffData = {
            staffIds: uniqueStaffIds,
        };

        addDoctorStaff(newStaffData)
            .then((res: any) => {
                if (res.status === 200) {
                    success(res?.data?.message);
                    fetchStaffList(); // Refresh the staff list after adding
                } else {
                    failed(res?.data?.message || 'Failed to add staff');
                }
            })
            .catch((error: any) => {
                failed('An error occurred while adding staff');
            })
            .finally(() => setSaveLoading(false));
    };
    
     const handleCancel = () => {
         // Remove only newly selected staff from selectedStaff on Cancel
         setSelectedStaff(selectedStaffsCache.current);
         setIsStaffChanged(false)
     };
    
    const handleKeyPress = (e: any) => {
        if (e.key === 'Enter') {
            fetchStaffList(searchQuery); // Trigger the search function when Enter is pressed
        }
    };
    
    return (
        <div className="main-dashboard-div">
            <div className="cards-wrapper">
                <div className="heading-dashboard">
                    <h2>Staff list</h2>
                    <Button
                        startIcon={<AddIcon />}
                        onClick={addStaffModal.open}
                    >
                        Add Staff
                    </Button>
                </div>
                <div className="search-box">
                    <input
                        type="text"
                        placeholder="Search"
                        className="search-input"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)} // Update search query
                        onKeyDown={handleKeyPress} // Listen for the Enter key
                    />
                    {searchQuery && (
                        <IconButton
                            type="button"
                            sx={{ p: '10px' }}
                            aria-label="clear search"
                            onClick={handleClearSearch}
                        >
                            <Clear />
                        </IconButton>
                    )}
                    <Button
                        startIcon={<SearchRounded />}
                        onClick={handleSearch}
                    >
                        Search
                    </Button>

                    <div className="save-buttons">
                        {/* Only show DialogActions if there are staff in the filtered list */}
                        {isStaffChanged && filteredStaffList?.length > 0 && (
                            <DialogActions>
                                <Button
                                    variant="secondary"
                                    onClick={handleCancel}
                                >
                                    Cancel
                                </Button>
                                <Button
                                    type="submit"
                                    onClick={handleSave}
                                    disabled={saveLoading}
                                >
                                    {saveLoading ? (
                                        <CircularProgress size={20} />
                                    ) : (
                                        'Save'
                                    )}
                                </Button>
                            </DialogActions>
                        )}
                    </div>
                </div>

                <DialogContent>
                    {isLoading ? (
                        <div style={{ textAlign: 'center', padding: '20px' }}>
                            <CircularProgress />
                        </div>
                    ) : null}

                    {!isLoading ? (
                        <>
                            <TableContainer component={Paper}>
                                <Table>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell></TableCell>
                                            <TableCell>Staff Name</TableCell>
                                            <TableCell>Email</TableCell>
                                            <TableCell>Contact</TableCell>
                                            <TableCell>Gender</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {filteredStaffList.length > 0 ? (
                                            filteredStaffList.map(
                                                (staff, index) => (
                                                    <TableRow
                                                        key={staff.id || index}
                                                        style={{
                                                            cursor: 'default', // Changes cursor to default to indicate non-clickable row
                                                        }}
                                                    >
                                                        <TableCell padding="checkbox">
                                                            <Checkbox
                                                                checked={selectedStaff.includes(
                                                                    staff.id
                                                                )}
                                                                onChange={() =>
                                                                    handleSelectChange(
                                                                        staff.id
                                                                    )
                                                                } // Only checkbox is clickable
                                                            />
                                                        </TableCell>
                                                        <TableCell align="left">
                                                            {staff.fullName}
                                                        </TableCell>
                                                        <TableCell align="left">
                                                            {staff.email}
                                                        </TableCell>
                                                        <TableCell align="left">
                                                            {staff.phoneNumber}
                                                        </TableCell>
                                                        <TableCell
                                                            align="left"
                                                            style={{
                                                                textTransform:
                                                                    'capitalize',
                                                            }}
                                                        >
                                                            {staff.gender}
                                                        </TableCell>
                                                    </TableRow>
                                                )
                                            )
                                        ) : (
                                            <TableRow>
                                                <TableCell
                                                    colSpan={5}
                                                    style={{
                                                        textAlign: 'center',
                                                    }}
                                                >
                                                    No staff found.
                                                </TableCell>
                                            </TableRow>
                                        )}
                                    </TableBody>
                                </Table>
                            </TableContainer>

                            {filteredStaffList?.length > 10 && (
                                <CustomPagination
                                    page={currentPage}
                                    totalPages={Math.ceil(
                                        totalCount / rowsPerPage
                                    )}
                                    handlePage={handleChangePage}
                                />
                            )}
                        </>
                    ) : null}
                </DialogContent>
                <AddStaffModal
                    isOpen={addStaffModal.isOpen}
                    onClose={addStaffModal.close}
                    onAddStaffRefetchList={fetchStaffList}
                />
            </div>
        </div>
    );
};

export default StaffList;
