import React, { useEffect, useState } from 'react';
import '../Profile/style.css';
import './style.css';
import NoImage from '@images/no-image.png';
import cameraimg from '@images/camera-img.svg';
import { Button } from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import { styled } from '@mui/material/styles';
import { useAppContext } from '../../contexts/AppContextProvider';
import { useModalDisclosure } from '@hooks/useDisclosure';
import EditProfileModal from './EditProfileModal';
import EditAddressModal from './EditAddressModal';
import InsuranceModal from './InsuranceModal';
import { useDoctorsAddresses } from '../../API/Doctor';
import { Address } from '@typing/global';
import { useNavigate } from 'react-router-dom';
import { uploadProfileImage } from '../../API/User';
import { failed } from '@components/Common/Toastify';
import storage from '@utils/storage';

function Profile() {
    const { value, setValue, handleLoading } = useAppContext();
    const navigate = useNavigate();

    const profileModal = useModalDisclosure();

    const addressModal = useModalDisclosure(
        value?.user?.doctorType === 'MD' && !value?.user?.hasAddress
    );
    const insuranceModal = useModalDisclosure();
    const VisuallyHiddenInput = styled('input')({
        clip: 'rect(0 0 0 0)',
        clipPath: 'inset(50%)',
        height: 1,
        overflow: 'hidden',
        position: 'absolute',
        bottom: 0,
        left: 0,
        whiteSpace: 'nowrap',
        width: 1,
    });

    const [profileImage, setProfileImage] = useState<string | null>(
        value?.user?.profileImage || null
    );

    const { data: doctorsAddressesList, refetch } = useDoctorsAddresses({
        doctorId: value?.user?.id, // doctor's id from doctor table
    });

    useEffect(() => {
        if (value?.user?.userType !== 'doctor') {
            navigate('/app/dashboard');
        }
    }, []);

    // Handle image upload
    const handleProfileImageChange = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        if (event.target.files && event.target.files[0]) {
            handleLoading(true);
            const formData = new FormData();
            formData.append('profileImage', event.target.files[0]);
            uploadProfileImage(formData)
                .then((res: any) => {
                    setValue({
                        ...value,
                        user: {
                            ...value.user,
                            profileImage: URL.createObjectURL(
                                event.target.files[0]
                            ),
                        },
                    });
                    storage.setUser({
                        ...value.user,
                        profileImage: res?.data?.data?.profileImage,
                    });
                    setProfileImage(URL.createObjectURL(event.target.files[0]));
                })
                .catch(() => failed('Image upload failed'))
                .finally(() => handleLoading(false));
        }
    };

    const capitalizeFirstLetter = (str: any) => {
        if (!str) return '';
        return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
    };

    return (
        <>
            <div className="main-view-div">
                <div className="view-heading add-staff-row">
                    <div>
                        <h4>Profile</h4>
                    </div>
                </div>

                <div className="view-details">
                    <div className="doctor-profile-div">
                        <div className="profle-wrapper">
                            {profileImage ? (
                                <img
                                    className="fixed-image"
                                    src={profileImage}
                                    alt="profile-img"
                                />
                            ) : (
                                <img
                                    className="fixed-image"
                                    src={NoImage}
                                    alt="profile-img"
                                />
                            )}
                            <img
                                src={cameraimg}
                                alt="profile-img"
                                className="camera-upload-img"
                            />
                            <div>
                                <h6 style={{ textTransform: 'capitalize' }}>
                                    {value?.user?.fullName}
                                </h6>
                                {/*<p>Dermatologist</p>*/}
                            </div>
                            <Button
                                component="label"
                                role={undefined}
                                variant="contained"
                                tabIndex={-1}
                                className="profile-upload-btn"
                                startIcon={<CloudUploadIcon />}
                            >
                                <VisuallyHiddenInput
                                    type="file"
                                    accept="image/png, image/jpeg, image/jpg"
                                    onChange={handleProfileImageChange}
                                />
                            </Button>
                        </div>
                        <div className="profile-edit-btn">
                            <Button
                                className="edit-btn"
                                onClick={profileModal.open}
                            >
                                Edit Profile
                            </Button>
                        </div>
                    </div>

                    <div className="profile-inner-wrapper">
                        <div className="profile-inputs">
                            <div className="d-flex name-fields">
                                <h4>Name : </h4>
                                <p style={{ textTransform: 'capitalize' }}>
                                    {value?.user?.firstName}{' '}
                                    {value?.user?.lastName}
                                </p>
                            </div>
                            <div className="d-flex name-fields">
                                <h4>Gender : </h4>
                                <p style={{ textTransform: 'capitalize' }}>
                                    {' '}
                                    {value?.user?.gender}
                                </p>
                            </div>
                            {/* <div className="d-flex name-fields">
                            <h4>Specialty :</h4>
                            <p>Ophthalmologist</p>
                        </div> */}
                        </div>
                        <div className="profile-inputs">
                            <div className="d-flex name-fields">
                                <h4>Phone : </h4>
                                <p>{value?.user?.phoneNumber}</p>
                            </div>
                            <div className="d-flex name-fields">
                                <h4>Email : </h4>
                                <p>{value?.user?.email}</p>
                            </div>
                            <div className="d-flex name-fields">
                                {/* <a
                                    style={{
                                        textDecoration: 'none',
                                        color: 'blue',
                                    }}
                                >
                                    <h4 onClick={insuranceModal.open}>
                                        Insurances
                                    </h4>
                                </a> */}
                            </div>
                            {/*<div className="d-flex name-fields">
                                <h4>Location:</h4>
                                <p style={{ textTransform: 'capitalize' }}>
                                    {value?.user?.location}
                                </p>
                            </div>*/}
                        </div>
                        <div className="profile-inputs">
                            <div className="d-flex name-fields">
                                <p className="insurance-link">
                                    <a
                                        onClick={insuranceModal.open}
                                        style={{
                                            textDecoration: 'underline',
                                            cursor: 'pointer',
                                        }}
                                    >
                                        Insurance Details{' '}
                                    </a>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div
                        className="profile-edit-btn"
                        style={{ textAlign: 'end', marginTop: '20px' }}
                    >
                        <Button
                            className="edit-btn"
                            onClick={addressModal.open}
                        >
                            Add Address
                        </Button>
                    </div>

                    <div className="profile-inner-wrapper">
                        <div className="address-inputs">
                            <div className="address-fields">
                                <h4>Address Information</h4>
                                {doctorsAddressesList?.length > 0 ? (
                                    doctorsAddressesList.map(
                                        (address: Address, index: number) => (
                                            <React.Fragment key={index}>
                                                <div className="address-item">
                                                    <h3
                                                        style={{
                                                            color: 'black',
                                                            textTransform:
                                                                'capitalize',
                                                        }}
                                                    >
                                                        {capitalizeFirstLetter(
                                                            address.addressTitle
                                                        )}
                                                    </h3>
                                                    <p>{address.phoneNumber}</p>
                                                    <p>{address.faxNumber}</p>
                                                    <p>{address.street}</p>
                                                    <p
                                                        style={{
                                                            textTransform:
                                                                'capitalize',
                                                        }}
                                                    >
                                                        {address.city},{' '}
                                                        {address.state}
                                                    </p>
                                                    <p
                                                        style={{
                                                            textTransform:
                                                                'capitalize',
                                                        }}
                                                    >
                                                        {address.country}
                                                    </p>
                                                    <p>{address.zipCode}</p>
                                                </div>
                                                {index <
                                                    doctorsAddressesList.length -
                                                        1 && (
                                                    <hr
                                                        className="address-separator"
                                                        style={{
                                                            marginTop: '15px',
                                                            marginBottom:
                                                                '15px',
                                                        }}
                                                    />
                                                )}
                                            </React.Fragment>
                                        )
                                    )
                                ) : (
                                    <p>No addresses available</p>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {profileModal.isOpen ? (
                <EditProfileModal
                    isOpen={profileModal.isOpen}
                    onClose={profileModal.close}
                />
            ) : null}
            {addressModal.isOpen ? (
                <EditAddressModal
                    isOpen={addressModal.isOpen}
                    onClose={addressModal.close}
                    addresses={doctorsAddressesList}
                    refetch={refetch}
                />
            ) : null}
            {insuranceModal.isOpen ? (
                <InsuranceModal
                    isOpen={insuranceModal.isOpen}
                    onClose={insuranceModal.close}
                />
            ) : null}
        </>
    );
}

export default Profile;
