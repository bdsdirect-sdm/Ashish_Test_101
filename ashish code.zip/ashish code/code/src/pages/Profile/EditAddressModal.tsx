import React from 'react';
import {
    Button as MuiButton,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    Accordion,
    AccordionSummary,
    Typography,
    AccordionDetails,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useFormik } from 'formik';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import '../Profile/style.css';
import './style.css';
import { updateUserAddresses } from '../../API/User';
import { failed, info, success } from '@components/Common/Toastify';
import { Address } from '@typing/global';
import { validationSchemaForEditAddress } from './constant';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Button from '@components/Common/Button';
import TextInput from '@components/Common/TextInput';
import { useAppContext } from '../../contexts/AppContextProvider';
import storage from '@utils/storage';

const EditAddressModal = ({
    isOpen,
    onClose,
    addresses,
    refetch,
}: {
    isOpen: boolean;
    onClose: () => void;
    addresses: Address[];
    refetch: () => void;
}) => {
    const { value, setValue } = useAppContext();
    const [expanded, setExpanded] = React.useState<number | false>(0);
    const [loading, setLoading] = React.useState<boolean>(false);

    const handleChange =
        (panel: number) =>
        (event: React.SyntheticEvent, isExpanded: boolean) => {
            setExpanded(isExpanded ? panel : false);
        };
    // Initialize formik with addresses from context
    const formik = useFormik({
        initialValues: {
            addresses:
                addresses?.length > 0
                    ? addresses
                    : [
                          {
                              street: '',
                              city: '',
                              state: '',
                              country: '',
                              zipCode: '',
                              addressTitle: '',
                              phoneNumber: '',
                              faxNumber: '',
                          },
                      ],
        },
        validationSchema: validationSchemaForEditAddress,
        onSubmit: async (values) => {
            setLoading(true);
            updateUserAddresses(values?.addresses)
                .then((response: any) => {
                    if (!value.user.hasAddress) {
                        const updatedContext = {
                            ...value,
                            user: { ...value.user, hasAddress: true },
                        };
                        setValue(updatedContext);
                        storage.setUser(updatedContext.user);
                    }
                    onClose(); // Close modal after successful save
                    refetch();
                    success(response?.data?.message);
                })
                .catch((error) => {
                    failed(error?.response?.data?.message);
                })
                .finally(() => setLoading(false));
        },
    });

    // Add a new address field
    const addAddressField = () => {
        if (formik.isValid) {
            formik.setFieldValue('addresses', [
                // eslint-disable-next-line no-unsafe-optional-chaining
                ...formik.values?.addresses,
                {
                    street: '',
                    city: '',
                    state: '',
                    country: '',
                    zipCode: '',
                    addressTitle: '',
                    phoneNumber: '',
                    faxNumber: '',
                },
            ]);
            setExpanded(formik.values.addresses.length);
        } else {
            info('Fill the previous addresses', 5000);
        }
    };

    // Remove an address field
    const removeAddressField = (index: number) => {
        formik.setFieldValue(
            'addresses',
            formik.values?.addresses.filter((_, i) => i !== index)
        );
    };

    return (
        <Dialog open={isOpen} onClose={onClose} fullWidth={true}>
            <DialogTitle>
                Edit Address
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <DialogContent>
                <form onSubmit={formik.handleSubmit}>
                    {formik.values?.addresses.map(
                        (address: Address, index: number) => (
                            <Accordion
                                key={index}
                                expanded={expanded === index}
                                onChange={handleChange(index)}
                            >
                                <AccordionSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panel1bh-content"
                                    id="1bh-header"
                                >
                                    <Typography
                                        sx={{
                                            textTransform: 'capitalize',
                                            width: '100%',
                                            fontWeight: '500',
                                        }}
                                    >
                                        {address?.addressTitle || 'New Address'}
                                    </Typography>
                                    <IconButton
                                        onClick={() =>
                                            removeAddressField(index)
                                        }
                                        style={{
                                            padding: 0,
                                            color: 'red',
                                            display:
                                                formik.values.addresses
                                                    ?.length > 1
                                                    ? 'inline-flex'
                                                    : 'none',
                                            float: 'right',
                                        }}
                                    >
                                        <DeleteIcon />
                                    </IconButton>
                                </AccordionSummary>
                                <AccordionDetails>
                                    <TextInput
                                        label="Address Title"
                                        keyField={`addresses[${index}].addressTitle`}
                                        value={address.addressTitle}
                                        onChange={formik.handleChange}
                                        formik={formik}
                                        error={
                                            formik.touched.addresses?.[index]
                                                ?.addressTitle &&
                                            (
                                                formik.errors.addresses?.[
                                                    index
                                                ] as Address
                                            )?.addressTitle
                                        }
                                    />
                                    <TextInput
                                        label="Office Phone Number"
                                        style={{ margin: '8px 0' }}
                                        type="phone"
                                        value={address?.phoneNumber}
                                        keyField={`addresses[${index}].phoneNumber`}
                                        formik={formik}
                                        error={
                                            formik.touched.addresses?.[index]
                                                ?.phoneNumber &&
                                            (
                                                formik.errors.addresses?.[
                                                    index
                                                ] as Address
                                            )?.phoneNumber
                                        }
                                    />
                                    <TextInput
                                        label="Fax Number"
                                        style={{ margin: '8px 0' }}
                                        type="phone"
                                        value={address?.faxNumber}
                                        required={false}
                                        keyField={`addresses[${index}].faxNumber`}
                                        formik={formik}
                                        error={
                                            formik.touched.addresses?.[index]
                                                ?.faxNumber &&
                                            (
                                                formik.errors.addresses?.[
                                                    index
                                                ] as Address
                                            )?.faxNumber
                                        }
                                    />
                                    <TextInput
                                        label="Street"
                                        keyField={`addresses[${index}].street`}
                                        value={address.street}
                                        onChange={formik.handleChange}
                                        formik={formik}
                                        error={
                                            formik.touched.addresses?.[index]
                                                ?.street &&
                                            (
                                                formik.errors.addresses?.[
                                                    index
                                                ] as Address
                                            )?.street
                                        }
                                    />
                                    <TextInput
                                        label="City"
                                        keyField={`addresses[${index}].city`}
                                        value={address.city}
                                        onChange={formik.handleChange}
                                        formik={formik}
                                        error={
                                            formik.touched.addresses?.[index]
                                                ?.city &&
                                            (
                                                formik.errors.addresses?.[
                                                    index
                                                ] as Address
                                            )?.city
                                        }
                                    />
                                    <TextInput
                                        label="State"
                                        keyField={`addresses[${index}].state`}
                                        value={address.state}
                                        onChange={formik.handleChange}
                                        formik={formik}
                                        error={
                                            formik.touched.addresses?.[index]
                                                ?.state &&
                                            (
                                                formik.errors.addresses?.[
                                                    index
                                                ] as Address
                                            )?.state
                                        }
                                    />
                                    <TextInput
                                        label="Country"
                                        keyField={`addresses[${index}].country`}
                                        value={address.country}
                                        onChange={formik.handleChange}
                                        formik={formik}
                                        error={
                                            formik.touched.addresses?.[index]
                                                ?.country &&
                                            (
                                                formik.errors.addresses?.[
                                                    index
                                                ] as Address
                                            )?.country
                                        }
                                    />
                                    <TextInput
                                        label="Zip Code"
                                        keyField={`addresses[${index}].zipCode`}
                                        type="text"
                                        value={address.zipCode}
                                        onChange={formik.handleChange}
                                        formik={formik}
                                        error={
                                            formik.touched.addresses?.[index]
                                                ?.zipCode &&
                                            (
                                                formik.errors.addresses?.[
                                                    index
                                                ] as Address
                                            )?.zipCode
                                        }
                                    />
                                </AccordionDetails>
                            </Accordion>
                        )
                    )}

                    <DialogActions>
                        <div style={{ width: '100%' }}>
                            <MuiButton
                                //variant="outlined"
                                color="secondary"
                                onClick={addAddressField}
                                startIcon={<AddIcon />}
                            >
                                Add Address
                            </MuiButton>
                        </div>
                    </DialogActions>
                    <DialogActions>
                        <Button variant="secondary" onClick={onClose}>
                            Cancel
                        </Button>
                        <Button type="submit" isLoading={loading}>
                            Save
                        </Button>
                    </DialogActions>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default EditAddressModal;
