import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Checkbox,
    CircularProgress,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { failed, success } from '@components/Common/Toastify';
import React, { useState, useEffect } from 'react';
import {
    getAllInsuranceWithDoctorInsurances,
    addDoctorInsurance,
} from '../../API/User';
import './style.css';
import Button from '@components/Common/Button';
import { DoctorInsurancesData } from '@typing/global';
import { useAppContext } from '../../contexts/AppContextProvider';

const InsuranceModal = ({
    isOpen,
    onClose,
}: {
    isOpen: boolean;
    onClose: () => void;
}) => {
    const { handleLoading } = useAppContext();
    // State to manage the insurance listing
    const [insuranceData, setInsuranceData] = useState<{
        allInsurances: any[];
        doctorInsurances: any[];
    } | null>(null);
    const [selectedDoctorInsurances, setSelectedDoctorInsurances] = useState<
        number[]
    >([]); // Store selected doctor insurance IDs
    const [selectedAllInsurances, setSelectedAllInsurances] = useState<
        number[]
    >([]); // Store selected all insurance IDs
    const [isLoading, setIsLoading] = useState<boolean>(false); // Track loading state

    // Fetch insurances when modal opens
    useEffect(() => {
        if (isOpen) {
            fetchInsurances();
        }
    }, [isOpen]);

    // Function to fetch insurances
    const fetchInsurances = () => {
        handleLoading(true); // Show loading spinner while fetching
        getAllInsuranceWithDoctorInsurances()
            .then((response: any) => {
                if (response?.data) {
                    setInsuranceData(response.data?.data); // Set the whole data
                    const existingDoctorInsuranceIds =
                        response.data?.data?.doctorInsurances.map(
                            (insurance: any) => insurance.id
                        );
                    setSelectedDoctorInsurances(existingDoctorInsuranceIds); // Prefill selectedDoctorInsurances
                } else {
                    setInsuranceData(null);
                    failed('Insurance data is not available.');
                }
            })
            .catch((error: any) => {
                setInsuranceData(null);
                console.log(error);
            })
            .finally(() => {
                handleLoading(false); // Hide spinner after data fetching
            });
    };

    // Function to handle checkbox change for doctor insurances
    const handleDoctorInsuranceChange = (id: number) => {
        setSelectedDoctorInsurances((prev) =>
            prev.includes(id)
                ? prev.filter((insuranceId) => insuranceId !== id)
                : [...prev, id]
        );
    };

    // Function to handle checkbox change for all insurances
    const handleAllInsuranceChange = (id: number) => {
        setSelectedAllInsurances((prev) =>
            prev.includes(id)
                ? prev.filter((insuranceId) => insuranceId !== id)
                : [...prev, id]
        );
    };

    // Function to handle save action
    const handleSave = () => {
        setIsLoading(true); // Set loading to true when the save process begins

        const combinedInsurances = [
            ...selectedDoctorInsurances,
            ...selectedAllInsurances,
        ];

        // Remove duplicates using Set
        const uniqueInsurances = Array.from(new Set(combinedInsurances));

        const dataToSend: DoctorInsurancesData = {
            insuranceIds: uniqueInsurances, // This assumes your API expects an array of insurance IDs
        };

        // Call the API to add doctor insurances
        addDoctorInsurance(dataToSend)
            .then((response: any) => {
                success(response?.data?.message);
                setIsLoading(false); // Set loading to false when the API call is successful
                onClose(); // Close the modal after saving
            })
            .catch((error) => {
                setIsLoading(false); // Set loading to false if there is an error
                failed('Failed to add doctor insurances.');
            });
    };

    return (
        <Dialog
            open={isOpen}
            onClose={onClose}
            disableEscapeKeyDown={true}
            fullWidth
        >
            <DialogTitle>
                Insurances
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <DialogContent>
                <TableContainer>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableCell width={'75px'}>Select</TableCell>
                                <TableCell>Company Name</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {/* Render Doctor Insurances */}
                            {insuranceData?.doctorInsurances &&
                                insuranceData.doctorInsurances.length > 0 && (
                                    <>
                                        {insuranceData.doctorInsurances.map(
                                            (insurance: any) => (
                                                <TableRow
                                                    key={insurance.id}
                                                    sx={{
                                                        height: '24px',
                                                        cursor: 'pointer',
                                                    }}
                                                    onClick={() => {
                                                        // Handle row click
                                                        handleDoctorInsuranceChange(
                                                            insurance.id
                                                        );
                                                    }}
                                                >
                                                    <TableCell>
                                                        <Checkbox
                                                            checked={selectedDoctorInsurances.includes(
                                                                insurance.id
                                                            )}
                                                            onClick={(
                                                                event
                                                            ) => {
                                                                event.stopPropagation(); // Prevent row click when clicking on checkbox
                                                            }}
                                                            onChange={() => {
                                                                handleDoctorInsuranceChange(
                                                                    insurance.id
                                                                ); // Handle checkbox change separately
                                                            }}
                                                        />
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            textTransform:
                                                                'capitalize',
                                                        }}
                                                    >
                                                        {insurance.companyName}
                                                    </TableCell>
                                                </TableRow>
                                            )
                                        )}
                                    </>
                                )}

                            {/* Render All Insurances */}
                            {insuranceData?.allInsurances &&
                                insuranceData.allInsurances.length > 0 && (
                                    <>
                                        {insuranceData.allInsurances.map(
                                            (insurance: any) => (
                                                <TableRow
                                                    key={insurance.id}
                                                    sx={{
                                                        height: '24px',
                                                        cursor: 'pointer',
                                                    }}
                                                    onClick={() => {
                                                        // Handle row click
                                                        handleAllInsuranceChange(
                                                            insurance.id
                                                        );
                                                    }}
                                                >
                                                    <TableCell>
                                                        <Checkbox
                                                            checked={selectedAllInsurances.includes(
                                                                insurance.id
                                                            )}
                                                            onClick={(
                                                                event
                                                            ) => {
                                                                event.stopPropagation(); // Prevent row click when clicking on checkbox
                                                            }}
                                                            onChange={() => {
                                                                handleAllInsuranceChange(
                                                                    insurance.id
                                                                ); // Handle checkbox change separately
                                                            }}
                                                        />
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            textTransform:
                                                                'capitalize',
                                                        }}
                                                    >
                                                        {insurance.companyName}
                                                    </TableCell>
                                                </TableRow>
                                            )
                                        )}
                                    </>
                                )}
                            {(!insuranceData?.allInsurances ||
                                insuranceData.allInsurances.length === 0) && (
                                <TableRow>
                                    <TableCell colSpan={2} align="center">
                                        No insurances available
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose} variant="secondary">
                    Cancel
                </Button>
                <Button
                    color="primary"
                    onClick={handleSave}
                    disabled={isLoading} // Disable button when loading
                    startIcon={
                        isLoading ? (
                            <CircularProgress size={20} color="inherit" />
                        ) : null
                    } // Show loading spinner
                >
                    Save
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default InsuranceModal;
