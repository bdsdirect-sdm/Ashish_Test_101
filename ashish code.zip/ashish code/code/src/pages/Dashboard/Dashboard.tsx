import React, { useState } from 'react';
import './style.css';
import diversity from '@images/diversity_2.svg';
import patient from '@images/card-patient.svg';
import doctor from '@images/card-doctor.png';
import CustomTable from '@components/Common/table/CustomTable';
import { Add as AddIcon } from '@mui/icons-material';
import { TableDataFields, TableHeadCells } from './constant';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../../contexts/AppContextProvider';
import Button from '@components/Common/Button';
import { usePatients } from '../../API/Patient';
import { defaultParams } from '@utils/global.constants';
import { useModalDisclosure } from '@hooks/useDisclosure';
import { TableActionsMethod } from '@typing/global';
import AddConsultNote from '@pages/Patient/AddConsultNote';
import dayjs from 'dayjs';
import { useDoctorsCount, useReferralCompletedCount, useReferralPlacedCount } from '../../API/Dashboard';

function Dashboard() {
    const navigate = useNavigate();
    const {
        value: { user },
    } = useAppContext();
    const IsOD = user?.doctorType === 'OD';
    const [params, setParams] = useState(defaultParams);
    const { isLoading, isFetching, data, refetch } = usePatients({
        params: { ...params, statusType: ['pending', 'scheduled'] },
    });

    // Function to format the date
    const formatDate = (dateString: any) => {
        const dateObj = new Date(dateString);

        // Array of month names for formatting
        const monthNames = [
            'Jan',
            'Feb',
            'Mar',
            'Apr',
            'May',
            'Jun',
            'Jul',
            'Aug',
            'Sep',
            'Oct',
            'Nov',
            'Dec',
        ];

        const day = dateObj.getDate();
        const month = monthNames[dateObj.getMonth()];
        return `${month} ${day}`;
    };

    // Fetching doctor count data
    const {
        data: doctorCountData,
    } = useDoctorsCount({});
    const [doctorCount, lastDoctorUpdated] = doctorCountData
        ? [
              doctorCountData.doctorsCount,
              formatDate(doctorCountData.lastUpdated),
          ]
        : [0, ''];

    // Fetching referral placed count data
    const {
        data: referralPlacedCountData,
    } = useReferralPlacedCount({});
    const [referralPlacedCount, lastReferralPlacedUpdated] =
        referralPlacedCountData
            ? [
                  referralPlacedCountData.referralsPlacedCount,
                  formatDate(referralPlacedCountData.lastUpdated),
              ]
            : [0, ''];
    
    // Fetching referral completed count data
    const {
        data: referralCompletedCountData
    } = useReferralCompletedCount({});
    const [referralCompletedCount, lastReferralCompletedUpdated] =
        referralCompletedCountData
            ? [
                  referralCompletedCountData.referralsCompletedCount,
                  formatDate(referralCompletedCountData.lastUpdated),
              ]
            : [0, ''];


    const IsMD = user?.doctorType === 'MD';
    const {
        isOpen,
        close,
        open,
        data: consultNoteData,
        setData: setConsultNoteData,
    } = useModalDisclosure();


    const handleTableActions = ({ action, data }: TableActionsMethod) => {
        switch (action) {
            case 'consultNote':
                open();
                setConsultNoteData(data);
                break;
            default:
                break;
        }
    };

    return (
        <>
            <div className="main-dashboard-div">
                <div className="dashboard-wrapper">
                    <div className="heading-dashboard">
                        <h2>Dashboard</h2>
                    </div>
                    <div className="outer-wrapper-cards">
                        <div
                            className="dashboard-cards"
                            onClick={() => navigate('/app/patient')}
                        >
                            <div className="margin-bottom">
                                <p>Referrals {IsMD ? 'Received' : 'Placed'}</p>
                            </div>
                            <div className="referral-div">
                                <img
                                    src={diversity}
                                    alt="profile"
                                    className="diversity-img"
                                />
                                <h4>{referralPlacedCount}</h4>
                            </div>
                            <div className="card-content">
                                <h6>
                                    Last update: {lastReferralPlacedUpdated}
                                </h6>
                            </div>
                        </div>
                        <div
                            className="dashboard-cards"
                            onClick={() =>
                                navigate('/app/patient', {
                                    state: { statusType: ['completed'] },
                                })
                            }
                        >
                            <div className="margin-bottom">
                                <p>Referrals Completed</p>
                            </div>
                            <div className="referral-div">
                                <img
                                    src={patient}
                                    alt="profile"
                                    className="diversity-img"
                                />
                                <h4>{referralCompletedCount}</h4>
                            </div>
                            <div className="card-content">
                                <h6>
                                    Last update: {lastReferralCompletedUpdated}
                                </h6>
                            </div>
                        </div>
                        <div
                            className="dashboard-cards"
                            onClick={() => navigate('/app/doctor')}
                        >
                            <div className="margin-bottom">
                                <p>{IsMD ? 'OD/MD' : 'MD'}</p>
                            </div>
                            <div className="referral-div">
                                <img
                                    src={doctor}
                                    alt="profile"
                                    className="diversity-img"
                                />
                                <h4>{doctorCount}</h4>
                            </div>
                            <div className="card-content">
                                <h6>Last update: {lastDoctorUpdated}</h6>
                            </div>
                        </div>
                    </div>
                    <div className="table-heading">
                        <h2>Referrals Placed</h2>
                        <Button
                            startIcon={<AddIcon />}
                            onClick={() =>
                                navigate(
                                    IsMD
                                        ? '/app/add-appointment'
                                        : '/app/add-patient'
                                )
                            }
                        >
                            {IsMD ? 'Add Appointment' : 'Add Referral Patient'}
                        </Button>
                    </div>

                    <div>
                        <CustomTable
                            tableData={data?.listing || []}
                            headCells={TableHeadCells(IsOD)}
                            dataFields={TableDataFields}
                            canView={false}
                            canDelete={false}
                            canEdit={false}
                            selectedUserAction={handleTableActions}
                            loading={isLoading}
                            fetching={isFetching}
                            totalPages={data?.totalPages || 0}
                            currentPage={data?.currentPage || 0}
                            hidePagination
                            handleSort={(sortKeyOrder) => {
                                setParams({ ...params, ...sortKeyOrder });
                            }}
                        />
                    </div>
                </div>
            </div>
            <AddConsultNote
                isOpen={isOpen}
                title={`${consultNoteData?.appointmentType} (${dayjs(
                    consultNoteData?.[
                        consultNoteData?.appointmentType === 'Consultation'
                            ? 'consultationAppointment'
                            : 'surgeryAppointment'
                    ]?.date
                ).format('MM-DD-YYYY')})`}
                referralId={consultNoteData?.referralId}
                onClose={close}
                refetch={refetch}
            />
        </>
    );
}

export default Dashboard;
