export const TableHeadCells = (IsOD: boolean) => [
    {
        id: 'fullName',
        label: 'Doctor name',
        sort: true,
        nested: 'fullName',
        style: { textWrap: 'nowrap', textTransform: 'capitalize' },
    },
    {
        id: 'referalPlaced',
        label: IsOD ? 'Referal placed' : 'Referal received',
        type: 'number',
        nested: 'referPlaced',
    },
    {
        id: 'referalCompleted',
        label: 'Referal completed',
        type: 'number',
        nested: 'referCompleted',
    },
    {
        id: 'avgTimeOfContact',
        label: 'Avg time of contact',
        nested: 'avgTimeOfContact',
    },
    {
        id: 'avgTimeOfConsult',
        label: 'Avg time of consult',
        nested: 'avgTimeOfConsult',
    },
    {
        id: 'phone',
        label: 'Phone',
        nested: 'phoneNumber',
    },
    {
        id: 'email',
        sort: true,
        label: 'Email',
        nested: 'email',
    },
    {
        id: 'type',
        label: 'Type',
        nested: 'doctorType',
    },
    // {
    //     id: 'actions',
    //     label: 'Actions',
    //     style: { textAlign: 'center' },
    // },
];
export const TableDataFields = [
    'fullName',
    'referalPlaced',
    'referalCompleted',
    'avgTimeOfContact',
    'avgTimeOfConsult',
    'phone',
    'email',
    'type',
    // 'actions',
];
