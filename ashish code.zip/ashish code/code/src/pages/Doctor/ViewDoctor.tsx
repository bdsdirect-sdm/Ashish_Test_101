import React from 'react';

const ViewDoctor = () => {
    return <div>ViewDoctor</div>;
};

export default ViewDoctor;
