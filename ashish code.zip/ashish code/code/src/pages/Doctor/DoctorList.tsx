import React, { useRef, useState } from 'react';
import '../Dashboard/style.css';
import './style.css';
import CustomTable from '@components/Common/table/CustomTable';
import { TableDataFields, TableHeadCells } from './constant';
import { useDoctors } from '../../API/Doctor';
import { defaultParams } from '@utils/global.constants';
import Button from '@components/Common/Button';
import { Clear, SearchRounded } from '@mui/icons-material';
import { useAppContext } from '../../contexts/AppContextProvider';
import { IconButton } from '@mui/material';

function DoctorList() {
    const [params, setParams] = useState(defaultParams);
    const {
        value: { user },
    } = useAppContext();
    const timeOutId = useRef(null);
    const { isLoading, isFetching, data, refetch } = useDoctors({
        params,
        config: { keepPreviousData: true },
    });
    const IsOD = user?.doctorType === 'OD';

    const handleParamsChange = (key: string, value: string | number) => {
        setParams({ ...params, [key]: value });
    };

    const handleKeyPress = (e: any) => {
        if (e.key === 'Enter') {
            refetch(); // Trigger the search function when Enter is pressed
        }
    };

    const handleClear = () => {
        setParams({ ...params, search: '' });
        timeOutId.current = setTimeout(() => {
            clearTimeout(timeOutId.current);
            refetch();
        }, 200);
    };

    return (
        <div className="main-dashboard-div">
            <div className="cards-wrapper">
                <div className="heading-dashboard">
                    <h2>Doctors list</h2>
                </div>
                <div className="search-box">
                    <input
                        type="text"
                        placeholder="Search"
                        className="search-input"
                        value={params.search}
                        onChange={(e) =>
                            handleParamsChange('search', e.target.value)
                        }
                        onKeyDown={handleKeyPress} // Listen for the Enter key
                    />
                    <IconButton
                        type="button"
                        sx={{
                            p: '10px',
                            display: params.search.length > 0 ? 'flex' : 'none',
                        }}
                        aria-label="search"
                        onClick={handleClear}
                    >
                        <Clear />
                    </IconButton>
                    <Button
                        startIcon={<SearchRounded />}
                        onClick={() => refetch()}
                    >
                        Search
                    </Button>
                </div>

                <CustomTable
                    tableData={data?.listing || []}
                    headCells={TableHeadCells(IsOD)}
                    dataFields={TableDataFields}
                    canView={false}
                    canDelete={false}
                    canEdit={false}
                    selectedUserAction={''}
                    loading={isLoading}
                    fetching={isFetching}
                    totalPages={data?.totalPages || 0}
                    currentPage={data?.currentPage || 0}
                    handlePageChange={(page) =>
                        page !== data?.currentPage &&
                        handleParamsChange('page', page)
                    }
                    handleSort={(sortKeyOrder) =>
                        setParams({ ...params, ...sortKeyOrder })
                    }
                />
            </div>
        </div>
    );
}

export default DoctorList;
