import React from 'react';
import { Outlet } from 'react-router-dom';
import Dashboard from '@pages/Dashboard/Dashboard';
import AuthAppLayout from '../components/Layouts/ProtectedLayout';

export const publicRoutes = [
    {
        path: '/auth',
        element: <AuthAppLayout />,
        children: [
            { path: 'setpassword', element: <Dashboard /> },
            // Uncomment and add your components as needed
            // { path: 'verifiedUserSetPass', element: <VerifiedUserSetPass /> },
            // { path: 'verifyMFA', element: <Verify /> },
            // { path: 'forgotpassword', element: <ForgotPassword isExpired={false} /> },
            // { path: 'resetpassword', element: <ResetPassword /> },
            // {
            //     path: 'reset-temporary-pass',
            //     element: <ForgotPassword isExpired={true} />,
            // },
            // { path: '*', element: <Navigate to="/" /> },
        ],
    },
];
