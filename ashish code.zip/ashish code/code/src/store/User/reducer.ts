import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { User } from '@typing/global';

export const initialUserState: User | null = null;

const slice = createSlice({
    name: 'User',
    initialState: initialUserState,
    reducers: {
        saveUser: (state, action: PayloadAction<User>) => {
            state = action.payload;
        },
        logout: (state) => {
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            state = null;
        },
    },
});

const { reducer } = slice;

export const { saveUser, logout } = slice.actions;

export default reducer;
