import { initialUserState } from './User/reducer';
import { PartialRootState } from './configureStore';

const getPreloadedState = (): PartialRootState => {
    return {
        User: {
            ...initialUserState,
        },
    };
};

export default getPreloadedState;
