import { User } from '@typing/global';

const storagePrefix = 'eye_refer_';

const storage = {
    getToken: () => {
        return JSON.parse(
            window.localStorage.getItem(`${storagePrefix}token`) as string
        );
    },
    setToken: (token: string) => {
        window.localStorage.setItem(
            `${storagePrefix}token`,
            JSON.stringify(token)
        );
    },
    clearToken: () => {
        window.localStorage.removeItem(`${storagePrefix}token`);
    },
    getUser: () => {
        return JSON.parse(
            window.localStorage.getItem(`${storagePrefix}user`) as string
        );
    },
    setUser: (user: User) => {
        window.localStorage.setItem(
            `${storagePrefix}user`,
            JSON.stringify(user)
        );
    },
    clearUser: () => {
        window.localStorage.removeItem(`${storagePrefix}user`);
    },
    getChatRoomId: () => {
        return JSON.parse(
            window.localStorage.getItem(`${storagePrefix}chatRoomId`) as string
        );
    },
    setChatRoomId: (chatRoomId: number) => {
        window.localStorage.setItem(
            `${storagePrefix}chatRoomId`,
            JSON.stringify(chatRoomId)
        );
    },
    clearChatRoomId: () => {
        window.localStorage.removeItem(`${storagePrefix}chatRoomId`);
    },
};

export default storage;
