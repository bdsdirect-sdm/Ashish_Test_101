import * as React from 'react';
import Pagination from '@mui/material/Pagination';
import Stack from '@mui/material/Stack';
import './Pagination.css';

interface Props {
    totalPages: number;
    page: number;
    handlePage: (pageNumber: number) => void;
}

const CustomPagination = ({ totalPages, page, handlePage }: Props) => {
    return (
        <div className="pagination-wrap">
            <Stack spacing={2}>
                <Pagination
                    shape="rounded"
                    page={page}
                    count={totalPages}
                    sx={{
                        '.MuiPagination-ul': { flexWrap: 'nowrap !important' },
                    }}
                    onChange={(e, page: number) => handlePage(page)}
                />
            </Stack>
        </div>
    );
};

export default CustomPagination;
