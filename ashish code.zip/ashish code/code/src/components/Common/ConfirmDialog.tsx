import React from 'react';
import {
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
} from '@mui/material';
import Button from './Button';

interface Props {
    open: boolean;
    title: string;
    message: string;
    entryName?: string;
    onConfirm: () => void;
    onDismiss: () => void;
    actionBtnTitle?: string;
}
const ConfirmMsg = ({
    open,
    title,
    message,
    entryName = '',
    onConfirm,
    onDismiss = () => {},
    actionBtnTitle = 'Submit',
}: Props) => {
    return (
        <Dialog open={open} onClose={onDismiss}>
            <DialogTitle>{title}</DialogTitle>
            <DialogContent>
                <DialogContentText>
                    {message}{' '}
                    {entryName ? (
                        <b style={{ textTransform: 'capitalize' }}>
                            {entryName}?
                        </b>
                    ) : (
                        ' this entry?'
                    )}
                </DialogContentText>
            </DialogContent>
            <DialogActions>
                <Button onClick={onDismiss} variant="secondary">
                    Cancel
                </Button>
                <Button onClick={onConfirm}>{actionBtnTitle}</Button>
            </DialogActions>
        </Dialog>
    );
};

export default ConfirmMsg;
