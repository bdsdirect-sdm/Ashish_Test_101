import { DesktopDatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { FormikProps } from 'formik';
import dayjs, { Dayjs } from 'dayjs';
import React, { useState } from 'react';

interface FormikValues {
    [key: string]: unknown;
}

interface Props {
    label: string;
    icon?: React.ReactNode | string;
    type?: string;
    keyField: string;
    formik: FormikProps<FormikValues>;
    disabled?: boolean;
    minDate?: Dayjs;
    maxDate?: Dayjs;
    required?: boolean;
    hasValue?: boolean;
    readOnly?: boolean;
}

function DateSelector({
    keyField,
    formik,
    label,
    minDate = dayjs().subtract(10, 'years'),
    maxDate = dayjs().add(20, 'years'),
    required = true,
    hasValue = false,
    readOnly = false,
}: Props) {
    const [value, setValue] = useState<Dayjs>(
        dayjs(`${formik.values[keyField]}`, 'MM-DD-YYYY')
    );
    const [open, setOpen] = useState(false);
    const handleChange = (val: Dayjs) => {
        formik.setFieldValue(keyField, dayjs(val).format('MM-DD-YYYY'));
        setValue(val);
        setOpen(false);
    };

    return (
        <div className="field-wrap">
            <label htmlFor={keyField}>
                {label}
                {required ? <span style={{ color: 'red' }}> *</span> : null}
            </label>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DesktopDatePicker
                    label={false}
                    format="MM-DD-YYYY"
                    minDate={minDate}
                    maxDate={maxDate}
                    value={
                        hasValue
                            ? dayjs(`${formik.values[keyField]}`, 'MM-DD-YYYY')
                            : value
                    }
                    onChange={handleChange}
                    readOnly={readOnly}
                    closeOnSelect
                    onOpen={() => !readOnly && setOpen(true)}
                    onClose={() => !readOnly && setOpen(false)}
                    open={open}
                    slotProps={{
                        popper: {
                            sx: {
                                '.MuiPickersYear-yearButton': {
                                    padding: 0,
                                },
                            },
                        },
                    }}
                    //slots={{
                    //    textField: (textFieldProps) => (
                    //        <TextField
                    //            //onKeyDown={onKeyDown}
                    //            //onBeforeInput={onKeyDown}
                    //            onClick={() => !readOnly && setOpen(true)}
                    //            {...textFieldProps}
                    //            error={false}
                    //        />
                    //    ),
                    //}}
                />
            </LocalizationProvider>
            <div>
                {formik?.touched[keyField] && formik?.errors[keyField] ? (
                    <div className="error-text">{`${formik?.errors?.[keyField]}`}</div>
                ) : null}
            </div>
        </div>
    );
}

export default DateSelector;
