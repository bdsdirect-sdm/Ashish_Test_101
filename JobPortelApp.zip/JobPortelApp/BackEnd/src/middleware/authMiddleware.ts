import { Request, Response, NextFunction } from 'express';
import jwt, { JwtPayload } from 'jsonwebtoken';

interface CustomRequest extends Request {
    user?: string | JwtPayload;
}

const authMiddleware = (req: CustomRequest, res: Response, next: NextFunction): void => {
    const authHeader = req.header('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        res.status(401).json({ message: 'Authentication failed. Token not provided.' })
        return ;
    }

    const token = authHeader.replace('Bearer ', '');

    if (!process.env.JWT_SECRET) {
         res.status(500).json({ message: 'Internal server error. JWT secret not configured.' })
         return;
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET) as JwtPayload;
        req.user = decoded; // Attach decoded user info to request object
        next();
    } catch (error) {
         res.status(401).json({ message: 'Authentication failed. Invalid token.' })
         return;
    }
};

export default authMiddleware;