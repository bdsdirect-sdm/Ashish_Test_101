import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';
import { Table, Spinner, Alert } from 'react-bootstrap';

interface Agency {
    id: string;
    name: string;
}

interface JobSeeker {
    id: string;
    name: string;
    Hobbies: string[];
    Resume: string;
    AssociatedAgencyID: string;
}

interface DecodedToken {
    id: string;
    role: string;
    // Add other properties as needed
}

const Dashboard: React.FC = () => {

    const [role, setRole] = useState<string | null>(null);
    const [user, setUser] = useState();
    const [data, setData] =
        useState<{ agencies: Agency[]; jobSeekers: JobSeeker[] }>({ agencies: [], jobSeekers: [] });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    console.log(data);

    // console.log(data);   




    useEffect(() => {
        const fetchData = async () => {
            try {
                const token = localStorage.getItem('token');
                if (!token) {
                    throw new Error('No token found');
                }


                const decodedToken: DecodedToken = jwtDecode(token);
                const userId = decodedToken.id;



                const roleResponse = await axios.get(`http://localhost:5000/api/user/${userId}`);
                setRole(roleResponse.data.role);

                const dataResponse = await axios.get(`http://localhost:5000/api/user/${userId}`);
                setData(dataResponse.data);
                setUser(dataResponse.data);
            }
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            catch (err) {
                setError('Failed to fetch data');
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    if (loading) {
        return <Spinner animation="border" />;
    }

    if (error) {
        return <Alert variant="danger">{error}</Alert>;
    }



    return (
        <div>

            <h1>Dashboard</h1>
            <p>Role Type: {role}</p>
            <table>
                <th>Name</th>
                <th>email</th>
                <th>agencyId</th>
                <th>gender</th>
                <th>hobbies</th>
                <th>phone</th>
            </table>
            {role == '2' ? (
                <>
                    <h2>Job Seekers</h2>
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Hobbies</th>
                                <th>Resume</th>
                            </tr>
                        </thead>
                        <tbody>
                            {data?.jobSeekers?.map((jobSeeker: JobSeeker) => (
                                <tr key={jobSeeker?.id}>
                                    <td>{jobSeeker?.name}</td>
                                    <td>{jobSeeker?.Hobbies.join(', ')}</td>
                                    <td><a href={jobSeeker?.Resume} target="_blank" rel="noopener noreferrer">View Resume</a></td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </>
            ) : role == '1' ? (
                <>
                    <h2>Agency Details</h2>
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th>Name</th>
                            </tr>
                        </thead>
                        <tbody>
                            {data?.agencies?.map((agency: Agency) => (
                                <tr key={agency?.id}>
                                    <td>{agency?.name}</td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </>
            )
                :
                (
                    <Alert variant="warning">User type not recognized</Alert>
                )
            }
        </div>
    );
};

export default Dashboard;
