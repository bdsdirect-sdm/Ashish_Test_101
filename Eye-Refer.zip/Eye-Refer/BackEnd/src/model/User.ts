import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database';
enum DoctorType {
    OD = "OD",
    MD = "MD",
    NULL = "NULL"
}

export class User extends Model {
    public firstName: string;
    public lastName: string;
    public gender: string;
    public doctorType: DoctorType;
    public email: string;
    public password: string;
    public location: string;
    public phoneNumber: string;
    public speciality: string;
    public address: string;

}
User.init({
    firstName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    lastName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    gender: {
        type: DataTypes.STRING,
        allowNull: false
    },
    doctorType: {
        type: DataTypes.ENUM,
        values: ['OD', 'MD', 'NULL'],
        allowNull: false
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },

    location: {
        type: DataTypes.STRING,
        allowNull: false
    },
    phoneNumber: {
        type: DataTypes.STRING,
        allowNull: false
    },
    speciality: {
        type: DataTypes.STRING,
        allowNull: false
    },
    address: {
        type: DataTypes.STRING,
        allowNull: false
    }

}, {
    sequelize, // pass your sequelize instance here
    tableName: 'users' // specify the table name
});
