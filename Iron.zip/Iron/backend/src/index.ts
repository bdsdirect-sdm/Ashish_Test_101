// import express, { Request, Response, Application } from "express";
// import nodemailer from "nodemailer";
// import dotenv from "dotenv";
// import Router from "./Route";

// // Load environment variables from .env
// dotenv.config();

// const app = express();
// const port = process.env.PORT || 3000;

// // Middleware to parse JSON requests
// app.use(express.json());

// // Create a Nodemailer transporter using the SMTP details from the environment variables
// const transporter = nodemailer.createTransport({
//   host: process.env.MAIL_HOST,
//   port: Number(process.env.MAIL_PORT),
//   auth: {
//     user: process.env.MAIL_USER,
//     pass: process.env.MAIL_PASS,
//   },
// });

// // Endpoint to send an email
// // app.post("/send-email", async (req: Request, res: Response) => {
// //   const { to, subject, text, html } = req.body;

// //   if (!to || !subject || !text) {
// //     return res.status(400).send("Missing required fields: to, subject, or text.");
// //   }

// //   const mailOptions = {
// //     from: process.env.MAIL_FROM, // Sender's email address
// //     to, // Receiver's email address
// //     subject, // Subject of the email
// //     text, // Plain text body of the email
// //     html, // HTML body of the email (optional)
// //   };

// //   try {
// //     // Send email using the transporter
// //     const info = await transporter.sendMail(mailOptions);
// //     console.log("Email sent: ", info.response);
// //     res.status(200).json({ message: "Email sent successfully", info });
// //   } catch (error) {
// //     console.error("Error sending email: ", error);
// //     res.status(500).json({ message: "Error sending email", error: (error as Error).message });
// //   }
// // });
// app.use("/", Router);
// // Start the server
// app.listen(port, () => {
//   console.log(`Server running at http://localhost:${port}`);
// });
const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
import cors from 'cors';
require('dotenv').config();

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Nodemailer Configuration
const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// Send Email Endpoint
app.post('/send-email', async (req:any, res:any) => {
  const { email, cart, totalAmount, deliveryDate } = req.body;

  const cartDetails = cart
    .map((item: { name: string; quantity: number; price: number }) => `<li>${item.name} (x${item.quantity}) - $${item.price * item.quantity}</li>`)
    .join('');

  const mailOptions = {
    from: `"Ecommerce Store" <${process.env.EMAIL_USER}>`,
    to: email,
    subject: 'Order Confirmation',
    html: `
      <h1>Order Confirmation</h1>
      <p>Thank you for your order! Here are your order details:</p>
      <ul>${cartDetails}</ul>
      <p><b>Total Amount:</b> $${totalAmount}</p>
      <p><b>Estimated Delivery Date:</b> ${deliveryDate}</p>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    res.status(200).send('Email sent successfully!');
  } catch (error) {
    console.error(error);
    res.status(500).send('Failed to send email.');
  }
});

// Start the Server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
