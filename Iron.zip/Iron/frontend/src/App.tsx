
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css'
import ProductsList from './components/ProductList'
import Cart from './components/Cart'
import Checkout from './components/Chackout'
import Success from './components/Sucess';


const App: React.FC = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<ProductsList />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/success" element={<Success />} />
      </Routes>
    </Router>
  );
};

export default App
