import React from 'react';


const Success: React.FC = () => {
   

    const handleContinueShopping = () => {
        window.location.href = '/';
    };

    return (
        <div className="container d-flex justify-content-center align-items-center" style={{ height: '100vh' }}>
            <div className="text-center">
            <h1 className="display-4">Successful Order Placed</h1>
            <button className="btn btn-primary mt-3" onClick={handleContinueShopping}>Continue Shopping</button>
            </div>
        </div>
    );
};

export default Success;