import React, { useState } from 'react';
import products from '../Data/products.json';
import 'bootstrap/dist/css/bootstrap.min.css';

const ProductsList: React.FC = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const productsPerPage = 5;

  const startIndex = (currentPage - 1) * productsPerPage;
  const paginatedProducts = products.slice(startIndex, startIndex + productsPerPage);

  const handleAddToCart = (product:any) => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    localStorage.setItem('cart', JSON.stringify([...cart, { ...product, quantity: 1 }]));
    alert('Added to cart!');
    // toast.success('Added to cart!');
  };

  return (
    <div className="container mt-5">
      <h1 className="text-primary">Products</h1>
    <div className="d-flex justify-content-end mb-3">
      <button className="btn btn-info" onClick={() => window.location.href = '/cart'}>View Cart</button>
    </div>
      {paginatedProducts.map((product) => (
        <div key={product.id} className="card mb-3">
          <div className="card-body">
            <h2 className="card-title">{product.name}</h2>  
            <img src={product.image} alt={product.name} className="img-fluid mb-2" style={{ width: '100px' }} />
            <p className="card-text">{product.description}</p>
            <p className='card-text'>Rating - {product.rating} &#11088;</p>
            <p className='card-text'>Price - ${product.price}</p>
            <button className="btn btn-primary" onClick={() => handleAddToCart(product)}>Add to Cart</button>
          </div>
        </div>
      ))}
      <div className="d-flex justify-content-between">
        <button className="btn btn-primary" disabled={currentPage === 1} onClick={() => setCurrentPage(currentPage - 1)}>Previous</button>
        <button className="btn btn-primary" disabled={startIndex + productsPerPage >= products.length} onClick={() => setCurrentPage(currentPage + 1)}>Next</button>
      </div>
    </div>
  );
};

export default ProductsList;