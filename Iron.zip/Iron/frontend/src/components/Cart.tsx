import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Cart: React.FC = () => {
  const [cart, setCart] = useState(JSON.parse(localStorage.getItem('cart') || '[]'));

  const handleQuantityChange = (id: number, quantity: number) => {
    const updatedCart = cart.map((item: any) =>
      item.id === id ? { ...item, quantity } : item
    );
    setCart(updatedCart);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
  };

  const handleRemove = (id: number) => {
    const updatedCart = cart.filter((item: any) => item.id !== id);
    setCart(updatedCart);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
  };

  const totalCost = cart.reduce((acc: number, item: any) => acc + item.price * item.quantity, 0);

  return (
    <div className="container mt-5">
      <h1 className="text-primary">Cart</h1>
      {cart.map((item: any) => (
        <div key={item.id} className="card mb-3">
          <div className="card-body">
            <h2 className="card-title">{item.name}</h2>
            <p className="card-text">Quantity: {item.quantity}</p>
            <input
              type="number"
              className="form-control mb-2"
              value={item.quantity}
              onChange={(e) => handleQuantityChange(item.id, parseInt(e.target.value))}
            />
            <button className="btn btn-danger" onClick={() => handleRemove(item.id)}>Remove</button>
          </div>
        </div>
      ))}
      <h3 className="text-info">Total Cost: ${totalCost}</h3>
      <a href="/checkout" className="btn btn-primary">Proceed to Checkout</a>
    </div>
  );
};

export default Cart;