// import React from 'react';
// import { Formik, Field, Form } from 'formik';
// import * as Yup from 'yup';
// import 'bootstrap/dist/css/bootstrap.min.css';

// const Checkout: React.FC = () => {
//   const validationSchema = Yup.object({
//     cardNumber: Yup.string().required('Required').length(16, 'Must be 16 digits'),
//     expiryDate: Yup.string().required('Required'),
//     cvv: Yup.string().required('Required').length(3, 'Must be 3 digits'),
//   });

//   const handleSubmit = (values: any) => {
//     console.log('Payment Details:', values);
//     // alert('Order placed successfully!');
//     localStorage.removeItem('cart');
//     window.location.href = '/success';
//   };

//   return (
//     <div className="container mt-5">
//       <h1 className="text-primary">Checkout</h1>
//       <Formik
//         initialValues={{ cardNumber: '', expiryDate: '', cvv: '' }}
//         validationSchema={validationSchema}
//         onSubmit={handleSubmit}
//       >
//         {({ errors, touched }) => (
//           <Form>
//             <div className="form-group">
//               <label>Card Number:</label>
//               <Field name="cardNumber" type="text" className="form-control" />
//               {errors.cardNumber && touched.cardNumber && <div className="text-danger">{errors.cardNumber}</div>}
//             </div>
//             <div className="form-group">
//               <label>Expiry Date:</label>
//               <Field name="expiryDate" type="text" className="form-control" />
//               {errors.expiryDate && touched.expiryDate && <div className="text-danger">{errors.expiryDate}</div>}
//             </div>
//             <div className="form-group">
//               <label>CVV:</label>
//               <Field name="cvv" type="text" className="form-control" />
//               {errors.cvv && touched.cvv && <div className="text-danger">{errors.cvv}</div>}
//             </div>
//             <button type="submit" className="btn btn-primary">Pay Now</button>
//           </Form>
//         )}
//       </Formik>
//     </div>
//   );
// };

// export default Checkout;

import React from 'react';
import { Formik, Field, Form } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';

const Checkout: React.FC = () => {
  const validationSchema = Yup.object({
    cardNumber: Yup.string().required('Required').length(16, 'Must be 16 digits'),
    expiryDate: Yup.string().required('Required'),
    cvv: Yup.string().required('Required').length(3, 'Must be 3 digits'),
    email: Yup.string().email('Invalid email').required('Required'),
  });

  const handleSubmit = async (values: any) => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const totalAmount = cart.reduce((acc: number, item: any) => acc + item.price * item.quantity, 0);
    const deliveryDate = new Date();
    deliveryDate.setDate(deliveryDate.getDate() + 7);

    try {
      await axios.post('http://localhost:5000/send-email', {
        email: values.email,
        cart,
        totalAmount,
        deliveryDate: deliveryDate.toDateString(),
      });
      alert('Order placed successfully! Confirmation email sent.');
      localStorage.removeItem('cart');
      window.location.href = '/success';
    } catch (error) {
      console.error(error);
      alert('Failed to place the order.');
    }
  };

  return (
    <div className="container mt-5">
      <h1 className="text-primary">Checkout</h1>
      <Formik
        initialValues={{ cardNumber: '', expiryDate: '', cvv: '', email: '' }}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        {({ errors, touched }) => (
          <Form>
            <div className="form-group">
              <label>Email:</label>
              <Field name="email" type="email" className="form-control" />
              {errors.email && touched.email && <div className="text-danger">{errors.email}</div>}
            </div>
            <div className="form-group">
              <label>Card Number:</label>
              <Field name="cardNumber" type="text" className="form-control" />
              {errors.cardNumber && touched.cardNumber && <div className="text-danger">{errors.cardNumber}</div>}
            </div>
            <div className="form-group">
              <label>Expiry Date:</label>
              <Field name="expiryDate" type="text" className="form-control" />
              {errors.expiryDate && touched.expiryDate && <div className="text-danger">{errors.expiryDate}</div>}
            </div>
            <div className="form-group">
              <label>CVV:</label>
              <Field name="cvv" type="text" className="form-control" />
              {errors.cvv && touched.cvv && <div className="text-danger">{errors.cvv}</div>}
            </div>
            <button type="submit" className="btn btn-primary">Pay Now</button>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default Checkout;