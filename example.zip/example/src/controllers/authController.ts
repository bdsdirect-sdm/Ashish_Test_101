
import { Request,Response } from "express";
import User from "../models/user.model"
import { sendWelcomeEmail } from "../config/mailer";
import bcrypt from 'bcrypt';


  export const registerUser =   async (req: any, res: any ) => {
    console.log('hello')
    try {
        const password = Math.random().toString(36).slice(-8);
        const hashedPassword = await bcrypt.hash(password, 10);
      const user = {        
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        phone: req.body.phone,
        gender: req.body.gender,
        userType: req.body.userType,
        hobbies: req.body.hobbies,
        profileImage: req.files['profileImage'][0].path,
        resume: req.body.user_type === 'Job Seeker' ? req.files['resume'][0].path : null,
        agencyId: req.body.user_type === 'Job Seeker' ? req.body.agencyId : null,
        password:hashedPassword,
      };
     
       const newUser=await User.create(user);
       console.log("newUser==",newUser)
       await sendWelcomeEmail(newUser.email,password)
      return res.status(201).json({ message: "User added successfully", user:newUser, });
  
    } catch (error) {
      console.error('Error adding user:', error);
      return res.status(500).json({ message: "Server error", error });
    }
  };
  

  export const loginUser = async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
  
      const user = await User.findOne({ where:email });
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
  
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
  
  
      return res.status(200).json({ message: "Login successful", user });
    } catch (error) {
      console.error('Error logging in user:', error);
      return res.status(500).json({ message: "Server error", error });
    }
  };